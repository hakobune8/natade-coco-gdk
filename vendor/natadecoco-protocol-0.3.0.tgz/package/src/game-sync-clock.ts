export interface ServerTimeEstimate {
  serverTime: number | null;
  uncertaintyMs: number | null;
  sampleAgeMs: number | null;
  stale: boolean;
}
interface ClockSample {
  receivedAt: number;
  anchor: number;
  roundTripMs: number;
}
/** Server time is anchored to a monotonic clock, never the device wall clock.
 * Half RTT describes uncertainty; asymmetric latency can exceed that estimate. */
export class GameServerClock {
  private samples: ClockSample[] = [];
  private readonly pending = new Map<string, number>();
  private suspended = false;
  constructor(private readonly monotonicNow: () => number) {}
  sent(messageId: string): void {
    if (this.suspended) return;
    if (this.pending.size >= 4)
      this.pending.delete(this.pending.keys().next().value!);
    this.pending.set(messageId, this.monotonicNow());
  }
  received(replyTo: string, serverTime: unknown): void {
    const sentAt = this.pending.get(replyTo);
    this.pending.delete(replyTo);
    if (
      this.suspended ||
      sentAt === undefined ||
      typeof serverTime !== "number" ||
      !Number.isSafeInteger(serverTime) ||
      serverTime < 0
    )
      return;
    const now = this.monotonicNow(),
      roundTripMs = now - sentAt;
    if (!Number.isFinite(roundTripMs) || roundTripMs < 0 || roundTripMs > 60000)
      return;
    this.samples = this.samples.filter(
      (sample) => now - sample.receivedAt <= 60000,
    );
    this.samples.push({
      receivedAt: now,
      anchor: serverTime + roundTripMs / 2,
      roundTripMs,
    });
    if (this.samples.length > 32) this.samples.shift();
  }
  getEstimate(): Readonly<ServerTimeEstimate> {
    const now = this.monotonicNow();
    this.samples = this.samples.filter(
      (sample) =>
        now - sample.receivedAt >= 0 && now - sample.receivedAt <= 60000,
    );
    const sample = this.samples.reduce<ClockSample | undefined>(
      (best, current) =>
        best === undefined || current.roundTripMs < best.roundTripMs
          ? current
          : best,
      undefined,
    );
    if (!sample)
      return Object.freeze({
        serverTime: null,
        uncertaintyMs: null,
        sampleAgeMs: null,
        stale: true,
      });
    const sampleAgeMs = now - sample.receivedAt;
    return Object.freeze({
      serverTime: sample.anchor + sampleAgeMs,
      uncertaintyMs: sample.roundTripMs / 2,
      sampleAgeMs,
      stale: this.suspended || sampleAgeMs > 30000,
    });
  }
  suspend(suspended: boolean): void {
    this.suspended = suspended;
    this.reset();
  }
  reset(): void {
    this.pending.clear();
    this.samples = [];
  }
}
