import assert from "node:assert/strict";
import { test } from "node:test";
import { PROTOCOL_VERSION, clampAxis, isNewerSequence, isProtocolEnvelope } from "./index.js";

test("validates protocol envelope version and type", () => {
  assert.equal(isProtocolEnvelope({ type: "heartbeat", protocolVersion: PROTOCOL_VERSION, messageId: "m1" }), true);
  assert.equal(isProtocolEnvelope({ type: "unknown", protocolVersion: PROTOCOL_VERSION, messageId: "m1" }), false);
  assert.equal(isProtocolEnvelope({ type: "heartbeat", protocolVersion: "2.0", messageId: "m1" }), false);
});

test("accepts only increasing safe sequences", () => {
  assert.equal(isNewerSequence(undefined, 0), true);
  assert.equal(isNewerSequence(41, 42), true);
  assert.equal(isNewerSequence(42, 42), false);
  assert.equal(isNewerSequence(42, 41), false);
  assert.equal(isNewerSequence(42, Number.MAX_SAFE_INTEGER + 1), false);
});

test("normalizes axes", () => {
  assert.equal(clampAxis(-2), -1);
  assert.equal(clampAxis(0.5), 0.5);
  assert.equal(clampAxis(Number.NaN), 0);
});
