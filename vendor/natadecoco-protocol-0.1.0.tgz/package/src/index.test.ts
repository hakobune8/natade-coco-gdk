import assert from "node:assert/strict";
import { test } from "node:test";
import {
  PROTOCOL_VERSION,
  TRANSIENT_INPUT_PAYLOAD_MAX_BYTES,
  clampAxis,
  isNewerSequence,
  isProtocolEnvelope,
  isTransientInputName,
  isTransientInputPayload
} from "./index.js";

test("validates protocol envelope version and type", () => {
  assert.equal(isProtocolEnvelope({ type: "heartbeat", protocolVersion: PROTOCOL_VERSION, messageId: "m1" }), true);
  assert.equal(isProtocolEnvelope({ type: "rtc.offer", protocolVersion: PROTOCOL_VERSION, messageId: "m2" }), true);
  assert.equal(isProtocolEnvelope({ type: "rtc.answer", protocolVersion: PROTOCOL_VERSION, messageId: "m3" }), true);
  assert.equal(isProtocolEnvelope({ type: "input.transient", protocolVersion: PROTOCOL_VERSION, messageId: "m4" }), true);
  assert.equal(isProtocolEnvelope({ type: "input.transient.received", protocolVersion: PROTOCOL_VERSION, messageId: "m5" }), true);
  assert.equal(isProtocolEnvelope({ type: "unknown", protocolVersion: PROTOCOL_VERSION, messageId: "m1" }), false);
  assert.equal(isProtocolEnvelope({ type: "heartbeat", protocolVersion: "2.0", messageId: "m1" }), false);
});

test("validates bounded transient input names and JSON payloads", () => {
  assert.equal(isTransientInputName("trigger.press"), true);
  assert.equal(isTransientInputName("bad name"), false);
  assert.equal(isTransientInputPayload({ strength: 0.8, tags: ["a", null] }), true);
  assert.equal(isTransientInputPayload({ value: Number.NaN }), false);
  assert.equal(isTransientInputPayload("x".repeat(TRANSIENT_INPUT_PAYLOAD_MAX_BYTES + 1)), false);
  const cyclic: Record<string, unknown> = {};
  cyclic.self = cyclic;
  assert.equal(isTransientInputPayload(cyclic), false);
});

test("accepts only increasing safe sequences", () => {
  assert.equal(isNewerSequence(undefined, 0), true);
  assert.equal(isNewerSequence(41, 42), true);
  assert.equal(isNewerSequence(42, 42), false);
  assert.equal(isNewerSequence(42, 41), false);
  assert.equal(isNewerSequence(42, Number.MAX_SAFE_INTEGER + 1), false);
});

test("normalizes axes", () => {
  assert.equal(clampAxis(-2), -1);
  assert.equal(clampAxis(0.5), 0.5);
  assert.equal(clampAxis(Number.NaN), 0);
});
