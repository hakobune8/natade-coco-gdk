export const PROTOCOL_VERSION = "1.0" as const;
export type ProtocolVersion = typeof PROTOCOL_VERSION;

export type SessionState =
  | "idle"
  | "waiting"
  | "ready"
  | "playing"
  | "finished"
  | "terminated"
  | "error";

export type JoinPolicy = "before-start" | "while-playing";

export type ConnectionState =
  | "idle"
  | "connecting"
  | "connected"
  | "reconnecting"
  | "closed"
  | "error";

export type ControllerProfile =
  | "button-only"
  | "directional-pad"
  | "dual-stick"
  | "steering"
  | "quiz-choice";

export interface Player {
  playerId: string;
  slot: number;
  displayName: string;
  connected: boolean;
  lastSeenAt: string;
}

export interface StickState {
  x: number;
  y: number;
}

export interface InputState {
  buttons?: Readonly<Record<string, boolean>>;
  stick?: StickState;
  leftStick?: StickState;
  rightStick?: StickState;
  steering?: number;
  throttle?: number;
  choice?: number | null;
}

export interface LatestInput {
  playerId: string;
  inputEpoch: string;
  sequence: number;
  acceptedAt: number;
  input: InputState;
}

export interface Ranking {
  playerId: string;
  rank: number;
  score?: number;
}

export interface GameCredits {
  developer?: string;
  artists?: readonly string[];
  music?: readonly string[];
}

export interface SessionSnapshot {
  sessionId: string;
  roomCode?: string;
  nodeId: string;
  gameId: string;
  state: SessionState;
  runId?: string;
  errorCode?: string;
  minPlayers: number;
  maxPlayers: number;
  joinPolicy?: JoinPolicy;
  createdAt: string;
  startedAt?: string;
  players: readonly Player[];
  latestInputs: Readonly<Record<string, LatestInput>>;
	rankings?: readonly Ranking[];
}

interface BaseMessage {
  type: string;
  protocolVersion: ProtocolVersion;
  messageId: string;
}

export interface WelcomeMessage extends BaseMessage {
  type: "welcome";
  connectionId: string;
  sessionId: string;
  role: "controller" | "display";
  heartbeatIntervalMs: number;
  serverTime: number;
  inputEpoch?: string;
  player?: Player;
  sessionState?: SessionState;
}

export interface InputMessage extends BaseMessage {
  type: "input";
  sessionId: string;
  playerId: string;
  connectionId: string;
  inputEpoch: string;
  sequence: number;
  clientTime: number;
  input: InputState;
}

export interface HeartbeatMessage extends BaseMessage {
  type: "heartbeat";
  connectionId: string;
  clientTime: number;
  replyTo?: string;
}

export interface SessionSnapshotMessage extends BaseMessage {
  type: "session.snapshot";
  serverTime: number;
  snapshot: SessionSnapshot;
}

export interface SessionStateChangedMessage extends BaseMessage {
  type: "session.state_changed";
  sessionId: string;
  serverTime: number;
  previousState: SessionState;
  state: SessionState;
}

export interface PlayerEventMessage extends BaseMessage {
  type: "player.joined" | "player.left" | "player.reconnected";
  sessionId: string;
  serverTime: number;
  player: Player;
}

export interface GameEventMessage extends BaseMessage {
  type: "game.started" | "game.ended";
  sessionId: string;
  runId: string;
  serverTime: number;
  rankings?: readonly Ranking[];
}

export interface InputChangedMessage extends BaseMessage {
  type: "input.changed";
  sessionId: string;
  playerId: string;
  inputEpoch: string;
  sequence: number;
  gatewayAcceptedAt: number;
  input: InputState;
}

export interface InputAckMessage extends BaseMessage {
  type: "input.ack";
  connectionId: string;
  acknowledgedMessageIds: readonly string[];
  displayReceivedAt: number;
}

export interface GameFinishMessage extends BaseMessage {
  type: "game.finish";
  sessionId: string;
  runId: string;
  rankings: readonly Ranking[];
}

export interface GameErrorMessage extends BaseMessage {
  type: "game.error";
  sessionId: string;
  runId: string;
  code: string;
}

export interface ErrorMessage extends BaseMessage {
  type: "error";
  code: string;
  retryable: boolean;
  publicMessage: string;
}

export type ControllerToServerMessage = InputMessage | HeartbeatMessage;
export type DisplayToServerMessage = HeartbeatMessage | InputAckMessage | GameFinishMessage | GameErrorMessage;
export type ServerToControllerMessage = WelcomeMessage | SessionStateChangedMessage | ErrorMessage | HeartbeatMessage;
export type ServerToDisplayMessage =
  | WelcomeMessage
  | SessionSnapshotMessage
  | SessionStateChangedMessage
  | PlayerEventMessage
  | GameEventMessage
  | InputChangedMessage
  | ErrorMessage
  | HeartbeatMessage;

export type RealtimeMessage =
  | ControllerToServerMessage
  | DisplayToServerMessage
  | ServerToControllerMessage
  | ServerToDisplayMessage;

export interface CatalogGame {
  id: string;
  displayName: string;
  version: string;
  minPlayers: number;
  maxPlayers: number;
  joinPolicy?: JoinPolicy;
  status: "ready" | "not-ready";
  launchable: boolean;
  displayUrl: string;
  controllerUrl: string;
  description?: string;
  credits?: GameCredits;
  presentation?: {
    catalogArtworkUrl: string;
    lobbyArtworkUrl: string;
    accentColor: string;
  };
  /** Administrator-only bounded diagnostic code. */
  reason?: "invalid-manifest" | "runtime-incompatible" | "duplicate-game-id" | "health-check-pending" | "health-check-failed" | "unavailable";
}

export interface CreateSessionRequest {
  gameId?: string;
  idempotencyKey: string;
  joinPolicy?: JoinPolicy;
}

export interface CreateSessionResponse {
  session: SessionSnapshot;
  joinUrl: string;
}

export interface RoomStatus {
	sessionId: string;
	gameId: string;
	state: SessionState;
	joinPolicy: JoinPolicy;
	minPlayers: number;
	maxPlayers: number;
	connectedPlayers: number;
}

export interface JoinResponse {
	sessionId: string;
	player: Player;
	token: string;
	tokenExpiresAt: string;
	reconnectHandle: string;
	controllerUrl: string;
}

export interface LauncherSessionView {
	session: SessionSnapshot;
	game: CatalogGame & { default?: boolean };
	joinUrl: string;
}

export interface JoinSessionRequest {
  displayName?: string;
  reconnectHandle?: string;
}

export interface JoinSessionResponse {
  sessionId: string;
  player: Player;
  token: string;
  tokenExpiresAt: string;
  reconnectHandle: string;
  controllerUrl: string;
}

const knownMessageTypes = new Set([
  "welcome", "input", "heartbeat", "session.snapshot", "session.state_changed",
  "player.joined", "player.left", "player.reconnected", "game.started", "game.ended",
  "input.changed", "input.ack", "game.finish", "game.error", "error"
]);

export function isProtocolEnvelope(value: unknown): value is BaseMessage {
  if (value === null || typeof value !== "object") return false;
  const message = value as Record<string, unknown>;
  return typeof message.type === "string"
    && knownMessageTypes.has(message.type)
    && message.protocolVersion === PROTOCOL_VERSION
    && typeof message.messageId === "string"
    && message.messageId.length > 0
    && message.messageId.length <= 128;
}

export function isNewerSequence(previous: number | undefined, next: number): boolean {
  return Number.isSafeInteger(next) && next >= 0 && (previous === undefined || next > previous);
}

export function clampAxis(value: number): number {
  if (!Number.isFinite(value)) return 0;
  return Math.max(-1, Math.min(1, value));
}
