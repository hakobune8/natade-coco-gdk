export const PROTOCOL_VERSION = "1.0" as const;
export type ProtocolVersion = typeof PROTOCOL_VERSION;

export const TRANSIENT_INPUT_NAME_MAX_LENGTH = 64;
export const TRANSIENT_INPUT_PAYLOAD_MAX_BYTES = 4096;

export type JsonPrimitive = string | number | boolean | null;
export type JsonValue = JsonPrimitive | readonly JsonValue[] | { readonly [key: string]: JsonValue };

export type SessionState =
  | "idle"
  | "waiting"
  | "ready"
  | "playing"
  | "finished"
  | "terminated"
  | "error";

export type JoinPolicy = "before-start" | "while-playing";

export type ConnectionState =
  | "idle"
  | "connecting"
  | "connected"
  | "reconnecting"
  | "closed"
  | "error";

export type ControllerProfile =
  | "button-only"
  | "directional-pad"
  | "dual-stick"
  | "steering"
  | "quiz-choice";

export interface Player {
  playerId: string;
  slot: number;
  displayName: string;
  connected: boolean;
  lastSeenAt: string;
}

export interface StickState {
  x: number;
  y: number;
}

export interface InputState {
  buttons?: Readonly<Record<string, boolean>>;
  stick?: StickState;
  leftStick?: StickState;
  rightStick?: StickState;
  steering?: number;
  throttle?: number;
  choice?: number | null;
}

export interface LatestInput {
  playerId: string;
  inputEpoch: string;
  sequence: number;
  acceptedAt: number;
  input: InputState;
}

export interface Ranking {
  playerId: string;
  rank: number;
  score?: number;
}

export interface GameCredits {
  developer?: string;
  artists?: readonly string[];
  music?: readonly string[];
}

export interface SessionSnapshot {
  sessionId: string;
  roomCode?: string;
  nodeId: string;
  gameId: string;
  state: SessionState;
  runId?: string;
  errorCode?: string;
  minPlayers: number;
  maxPlayers: number;
  joinPolicy?: JoinPolicy;
  createdAt: string;
  startedAt?: string;
  players: readonly Player[];
  latestInputs: Readonly<Record<string, LatestInput>>;
	rankings?: readonly Ranking[];
}

interface BaseMessage {
  type: string;
  protocolVersion: ProtocolVersion;
  messageId: string;
}

export interface WelcomeMessage extends BaseMessage {
  type: "welcome";
  connectionId: string;
  sessionId: string;
  role: "controller" | "display";
  heartbeatIntervalMs: number;
  serverTime: number;
  inputEpoch?: string;
  player?: Player;
  sessionState?: SessionState;
  transports?: readonly ("websocket" | "webrtc")[];
}

export interface InputMessage extends BaseMessage {
  type: "input";
  sessionId: string;
  playerId: string;
  connectionId: string;
  inputEpoch: string;
  sequence: number;
  clientTime: number;
  input: InputState;
}

export interface TransientInputMessage extends BaseMessage {
  type: "input.transient";
  sessionId: string;
  playerId: string;
  connectionId: string;
  inputEpoch: string;
  sequence: number;
  clientTime: number;
  name: string;
  payload: JsonValue;
}

export interface HeartbeatMessage extends BaseMessage {
  type: "heartbeat";
  connectionId: string;
  clientTime: number;
  replyTo?: string;
}

export interface SessionSnapshotMessage extends BaseMessage {
  type: "session.snapshot";
  serverTime: number;
  snapshot: SessionSnapshot;
}

export interface SessionStateChangedMessage extends BaseMessage {
  type: "session.state_changed";
  sessionId: string;
  serverTime: number;
  previousState: SessionState;
  state: SessionState;
}

export interface PlayerEventMessage extends BaseMessage {
  type: "player.joined" | "player.left" | "player.reconnected";
  sessionId: string;
  serverTime: number;
  player: Player;
}

export interface GameEventMessage extends BaseMessage {
  type: "game.started" | "game.ended";
  sessionId: string;
  runId: string;
  serverTime: number;
  rankings?: readonly Ranking[];
}

export interface InputChangedMessage extends BaseMessage {
  type: "input.changed";
  sessionId: string;
  playerId: string;
  inputEpoch: string;
  sequence: number;
  gatewayAcceptedAt: number;
  input: InputState;
}

export interface TransientInputReceivedMessage extends BaseMessage {
  type: "input.transient.received";
  sessionId: string;
  playerId: string;
  inputEpoch: string;
  sequence: number;
  clientTime: number;
  gatewayAcceptedAt: number;
  name: string;
  payload: JsonValue;
}

export interface InputAckMessage extends BaseMessage {
  type: "input.ack";
  connectionId: string;
  acknowledgedMessageIds: readonly string[];
  displayReceivedAt: number;
}

export interface RTCOfferMessage extends BaseMessage {
  type: "rtc.offer";
  sessionId: string;
  connectionId: string;
  sdp: string;
}

export interface RTCAnswerMessage extends BaseMessage {
  type: "rtc.answer";
  connectionId: string;
  sdp: string;
}

export interface GameFinishMessage extends BaseMessage {
  type: "game.finish";
  sessionId: string;
  runId: string;
  rankings: readonly Ranking[];
}

export interface GameErrorMessage extends BaseMessage {
  type: "game.error";
  sessionId: string;
  runId: string;
  code: string;
}

export interface ErrorMessage extends BaseMessage {
  type: "error";
  code: string;
  retryable: boolean;
  publicMessage: string;
}

export type ControllerToServerMessage = InputMessage | TransientInputMessage | HeartbeatMessage | RTCOfferMessage;
export type DisplayToServerMessage = HeartbeatMessage | InputAckMessage | GameFinishMessage | GameErrorMessage | RTCOfferMessage;
export type ServerToControllerMessage = WelcomeMessage | SessionStateChangedMessage | ErrorMessage | HeartbeatMessage | RTCAnswerMessage;
export type ServerToDisplayMessage =
  | WelcomeMessage
  | SessionSnapshotMessage
  | SessionStateChangedMessage
  | PlayerEventMessage
  | GameEventMessage
  | InputChangedMessage
  | TransientInputReceivedMessage
  | RTCAnswerMessage
  | ErrorMessage
  | HeartbeatMessage;

export type RealtimeMessage =
  | ControllerToServerMessage
  | DisplayToServerMessage
  | ServerToControllerMessage
  | ServerToDisplayMessage;

export interface CatalogGame {
  kind?: "game";
  id: string;
  displayName: string;
  version: string;
  minPlayers: number;
  maxPlayers: number;
  joinPolicy?: JoinPolicy;
  waitingTimeoutSeconds?: number;
  reconnectGraceSeconds?: number;
  /** Informational expected play time; Session Manager does not enforce it. */
  gameDurationSeconds?: number;
  resultDisplaySeconds?: number;
  status: "ready" | "not-ready";
  launchable: boolean;
  default?: boolean;
  displayUrl: string;
  controllerUrl: string;
  description?: string;
  credits?: GameCredits;
  presentation?: {
    catalogArtworkUrl: string;
    lobbyArtworkUrl: string;
    accentColor: string;
  };
  /** Administrator-only bounded diagnostic code. */
  reason?: "invalid-manifest" | "runtime-incompatible" | "duplicate-game-id" | "health-check-pending" | "health-check-failed" | "unavailable";
}

export interface CatalogWebsite {
  kind: "website";
  id: string;
  displayName: string;
  status: "ready" | "not-ready";
  launchable: boolean;
  launchUrl: string;
  description?: string;
  default?: boolean;
  presentation?: {
    catalogArtworkUrl?: string;
    accentColor: string;
  };
  controller: {
    pointer: boolean;
    primaryClick: boolean;
    scroll: boolean;
    back: boolean;
    home: true;
  };
  /** Administrator-only bounded diagnostic code. */
  reason?: "invalid-manifest" | "health-check-pending" | "health-check-failed" | "unavailable";
}

export type CatalogItem = CatalogGame | CatalogWebsite;

export interface CreateSessionRequest {
  gameId?: string;
  idempotencyKey: string;
  joinPolicy?: JoinPolicy;
  waitingTimeoutSeconds?: number;
  reconnectGraceSeconds?: number;
  resultDisplaySeconds?: number;
}

export interface CreateSessionResponse {
  session: SessionSnapshot;
  joinUrl: string;
}

export interface RoomStatus {
	sessionId: string;
	gameId: string;
	state: SessionState;
	joinPolicy: JoinPolicy;
	minPlayers: number;
	maxPlayers: number;
	connectedPlayers: number;
}

export interface JoinResponse {
	sessionId: string;
	player: Player;
	token: string;
	tokenExpiresAt: string;
	reconnectHandle: string;
	controllerUrl: string;
}

export interface LauncherSessionView {
	session: SessionSnapshot;
	game: CatalogGame & { default?: boolean };
	joinUrl: string;
}

export interface JoinSessionRequest {
  displayName?: string;
  reconnectHandle?: string;
}

export interface JoinSessionResponse {
  sessionId: string;
  player: Player;
  token: string;
  tokenExpiresAt: string;
  reconnectHandle: string;
  controllerUrl: string;
}

const knownMessageTypes = new Set([
  "welcome", "input", "input.transient", "heartbeat", "session.snapshot", "session.state_changed",
  "player.joined", "player.left", "player.reconnected", "game.started", "game.ended",
  "input.changed", "input.transient.received", "input.ack", "rtc.offer", "rtc.answer", "game.finish", "game.error", "error"
]);

export function isProtocolEnvelope(value: unknown): value is BaseMessage {
  if (value === null || typeof value !== "object") return false;
  const message = value as Record<string, unknown>;
  return typeof message.type === "string"
    && knownMessageTypes.has(message.type)
    && message.protocolVersion === PROTOCOL_VERSION
    && typeof message.messageId === "string"
    && message.messageId.length > 0
    && message.messageId.length <= 128;
}

export function isNewerSequence(previous: number | undefined, next: number): boolean {
  return Number.isSafeInteger(next) && next >= 0 && (previous === undefined || next > previous);
}

export function isTransientInputName(value: unknown): value is string {
  return typeof value === "string"
    && value.length <= TRANSIENT_INPUT_NAME_MAX_LENGTH
    && /^[A-Za-z][A-Za-z0-9._-]*$/u.test(value);
}

export function isTransientInputPayload(value: unknown): value is JsonValue {
  if (!validJsonValue(value, new Set<object>(), 0)) return false;
  try {
    const encoded = JSON.stringify(value);
    return encoded !== undefined && new TextEncoder().encode(encoded).byteLength <= TRANSIENT_INPUT_PAYLOAD_MAX_BYTES;
  } catch {
    return false;
  }
}

function validJsonValue(value: unknown, ancestors: Set<object>, depth: number): boolean {
  if (depth >= 32) return false;
  if (value === null || typeof value === "string" || typeof value === "boolean") return true;
  if (typeof value === "number") return Number.isFinite(value);
  if (typeof value !== "object" || ancestors.has(value)) return false;
  const prototype = Object.getPrototypeOf(value);
  if (!Array.isArray(value) && prototype !== Object.prototype && prototype !== null) return false;
  ancestors.add(value);
  for (const child of Array.isArray(value) ? value : Object.values(value as Record<string, unknown>)) {
    if (!validJsonValue(child, ancestors, depth + 1)) {
      ancestors.delete(value);
      return false;
    }
  }
  ancestors.delete(value);
  return true;
}

export function clampAxis(value: number): number {
  if (!Number.isFinite(value)) return 0;
  return Math.max(-1, Math.min(1, value));
}
