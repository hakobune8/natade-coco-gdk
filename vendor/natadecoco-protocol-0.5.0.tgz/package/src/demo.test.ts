import assert from "node:assert/strict";
import test from "node:test";
import { DemoRuntime, isDemoSnapshot, parseDemoQuery, type DemoAction, type DemoContext, type DemoSnapshot, type GameDemoDriver } from "./demo.js";
const binding = { sessionId: "session-1", gameId: "sample", runId: "run-1" };
const state = (patch: Partial<DemoSnapshot> = {}): DemoSnapshot => ({ contractVersion: 1, ...binding, enabled: true, generation: 1, revision: 1, phase: "preparing", errorCode: null, displayPrepared: false, controllers: [{ playerId: "p1", slot: 1, prepared: false }], ...patch });
const flush = async () => { await new Promise<void>(resolve => setImmediate(resolve)); };
const deferred = () => {
  let resolve!: () => void;
  let reject!: (error: Error) => void;
  const promise = new Promise<void>((done, fail) => { resolve = done; reject = fail; });
  return { promise, resolve, reject };
};

test("Display URL preserves existing query and accepts only one explicit binary demo flag", () => {
  assert.equal(parseDemoQuery("?sessionId=abc&gameId=sample&demo=1"), true);
  for (const query of ["", "?sessionId=abc", "?demo=0"]) assert.equal(parseDemoQuery(query), false);
  for (const query of ["?demo", "?demo=true", "?demo=01", "?demo=1&demo=0", "?demo=1&demo=1"]) assert.throws(() => parseDemoQuery(query));
});
test("mode validation fences run, safe counters, closed shapes and duplicate player identity", () => {
  assert.equal(isDemoSnapshot(state(), binding), true);
  for (const patch of [{ runId: "old-run" }, { revision: 2 ** 53 }, { enabled: false }, { controllers: [{ playerId: "p1", slot: 1, prepared: false }, { playerId: "p1", slot: 2, prepared: true }] }]) assert.equal(isDemoSnapshot(state(patch), binding), false);
  assert.equal(isDemoSnapshot({ ...state(), authorityEpoch: "secret" }, binding), false);
});
test("prepare/readiness/running are ordered and off cancels input without resetting board", async () => {
  const sent: DemoAction[] = [], calls: string[] = [];
  let signal: AbortSignal | undefined;
  const runtime = new DemoRuntime("controller", () => binding, action => { sent.push(action); return true; }, () => calls.push("neutral"));
  const driver: GameDemoDriver = { contractVersion: 1, async prepare(context) { signal = context.signal; calls.push("prepare"); }, async run(context) { calls.push("run"); await context.sleep(100_000); }, stop(reason) { calls.push(`stop:${reason}`); } };
  runtime.registerDriver(driver); runtime.connection(true); runtime.receive(state(), binding);
  await flush(); assert.deepEqual(calls, []);
  runtime.setReady(true); await flush(); assert.deepEqual(calls, ["prepare"]);
  assert.deepEqual(sent, [{ type: "demo.surface.ready", generation: 1, prepared: true }]);
  runtime.receive(state({ phase: "running", revision: 2 }), binding); await flush(); assert.equal(calls[1], "run");
  runtime.receive(state({ phase: "off", enabled: false, generation: 2, revision: 3 }), binding); await flush();
  assert.equal(signal?.aborted, true); assert.deepEqual(calls.slice(-2), ["neutral", "stop:off"]);
  assert.equal(sent.some(action => action.type === "demo.fail" || action.type === "demo.complete"), false);
});
test("late preparation cannot report readiness after disconnect; reconnect prepares a new generation", async () => {
  const sent: DemoAction[] = []; let resolve: (() => void) | undefined; let prepared = 0;
  const runtime = new DemoRuntime("display", () => binding, action => { sent.push(action); return true; });
  runtime.registerDriver({ contractVersion: 1, prepare: () => { prepared++; return new Promise<void>(done => { resolve = done; }); }, async run() {}, stop() {} });
  runtime.connection(true); runtime.setReady(true); runtime.receive(state(), binding); await flush();
  runtime.disconnect(); resolve?.(); await flush(); assert.equal(sent.length, 0);
  runtime.connection(true); runtime.receive(state({ generation: 2, revision: 2 }), binding); runtime.setReady(true); await flush();
  resolve?.(); await flush(); assert.equal(prepared, 2); assert.equal(sent.at(-1)?.generation, 2);
  runtime.receive(state({ generation: 2, revision: 3, phase: "running" }), binding); await flush();
  assert.equal(sent.at(-1)?.type, "demo.complete"); runtime.disconnect();
});
test("old snapshots do not resume cancelled tasks and a Controller cannot select mode", async () => {
  const sent: DemoAction[] = []; let count = 0;
  const runtime = new DemoRuntime("controller", () => binding, action => { sent.push(action); return true; });
  runtime.registerDriver({ contractVersion: 1, async prepare() { count++; }, async run() {}, stop() {} });
  runtime.connection(true); runtime.setReady(true); runtime.receive(state({ revision: 3, generation: 2 }), binding); await flush();
  runtime.receive(state(), binding); await flush(); assert.equal(count, 1); assert.equal(runtime.getState()?.generation, 2);
  assert.throws(() => runtime.setDesired(true)); runtime.disconnect();
});
test("unsupported Runtime keeps ordinary game readiness independent and sends no demo command", async () => {
  const sent: DemoAction[] = [];
  const runtime = new DemoRuntime("display", () => binding, action => { sent.push(action); return true; });
  runtime.setDesired(true); runtime.connection(false); runtime.setReady(true); await flush();
  assert.equal(runtime.getError(), "demo_contract_unsupported"); assert.equal(sent.length, 0);
});
test("sync loss sends not-ready, aborts a running driver and ignores its late completion", async () => {
  const sent: DemoAction[] = []; let resolve: (() => void) | undefined;
  const runtime = new DemoRuntime("display", () => binding, action => { sent.push(action); return true; });
  runtime.registerDriver({ contractVersion: 1, async prepare() {}, run: () => new Promise<void>(done => { resolve = done; }), stop() {} });
  runtime.connection(true); runtime.setReady(true); runtime.receive(state({ phase: "running" }), binding); await flush();
  runtime.setReady(false); resolve?.(); await flush();
  assert.equal(sent.at(-1)?.prepared, false); assert.equal(sent.some(action => action.type === "demo.complete"), false);
});

test("late game actions are fenced after off while ordinary manual input remains available", async () => {
  let context: DemoContext | undefined, presses = 0;
  const runtime = new DemoRuntime("controller", () => binding, () => true);
  runtime.registerDriver({ contractVersion: 1, async prepare() {}, async run(value) { context = value; await value.sleep(100_000); }, stop() {} });
  runtime.connection(true); runtime.setReady(true); runtime.receive(state({ phase: "running" }), binding); await flush();
  context!.perform(() => presses++); assert.equal(presses, 1);
  runtime.receive(state({ phase: "off", enabled: false, generation: 2, revision: 2 }), binding); await flush();
  context!.perform(() => presses++); assert.equal(presses, 1);
  presses++; assert.equal(presses, 2);
});

test("driver errors fail demo independently of the game and missing drivers never run", async () => {
  const sent: DemoAction[] = [];
  const runtime = new DemoRuntime("display", () => binding, action => { sent.push(action); return true; });
  runtime.registerDriver({ contractVersion: 1, async prepare() { throw new Error("fixture preparation failure"); }, async run() { assert.fail("run before prepare"); }, stop() {} });
  runtime.connection(true); runtime.setReady(true); runtime.receive(state(), binding); await flush();
  assert.equal(sent.at(-1)?.errorCode, "demo_prepare_failed"); runtime.disconnect();
  const missing = new DemoRuntime("controller", () => binding, action => { sent.push(action); return true; });
  missing.missingDriver(); missing.connection(true); missing.setReady(true); missing.receive(state(), binding); await flush();
  assert.equal(sent.at(-1)?.errorCode, "demo_driver_missing"); missing.disconnect();
});

test("the generated demo wire schema rejects null/extra fields and accepts all four closed requests", async () => {
  const { validateGameDemoClientMessage: validate } = await import("./demo.js");
  const envelope = { protocolVersion: "1.0", contractVersion: 1, messageId: "request-1", connectionId: "connection-1", ...binding, generation: 0 };
  for (const action of [{ type: "demo.mode.set", enabled: true }, { type: "demo.surface.ready", prepared: false }, { type: "demo.complete" }, { type: "demo.fail", errorCode: "demo_run_failed" }]) assert.equal(validate({ ...envelope, ...action }), true);
  for (const action of [{ type: "demo.mode.set", enabled: null }, { type: "demo.complete", prepared: null }, { type: "demo.surface.ready", prepared: true, playerId: "someone-else" }]) assert.equal(validate({ ...envelope, ...action }), false);
});

test("a completed Controller sequence releases input once and does not restart on another surface update", async () => {
  let runs = 0, releases = 0;
  const runtime = new DemoRuntime("controller", () => binding, () => true, () => releases++);
  runtime.registerDriver({ contractVersion: 1, async prepare() {}, async run() { runs++; }, stop() {} });
  runtime.connection(true); runtime.setReady(true); runtime.receive(state({ phase: "running" }), binding); await flush();
  runtime.receive(state({ phase: "running", revision: 2 }), binding); await flush();
  assert.equal(runs, 1); assert.equal(releases, 1); runtime.disconnect();
});

test("an invalid Display query cannot join a previously enabled demo after reconnect", async () => {
  let prepared = 0; const sent: DemoAction[] = [];
  const runtime = new DemoRuntime("display", () => binding, action => { sent.push(action); return true; });
  runtime.registerDriver({ contractVersion: 1, async prepare() { prepared++; }, async run() {}, stop() {} });
  runtime.invalidConfiguration("demo_query_invalid"); runtime.connection(true); runtime.setReady(true); runtime.receive(state(), binding); await flush();
  assert.equal(prepared, 0); assert.equal(sent.at(-1)?.errorCode, "demo_query_invalid"); runtime.disconnect();
});

test("a rejected old readiness report cannot cancel a newer running generation", async () => {
  let context: DemoContext | undefined;
  const runtime = new DemoRuntime("controller", () => binding, () => true);
  runtime.registerDriver({ contractVersion: 1, async prepare() {}, async run(value) { context = value; await value.sleep(100_000); }, stop() {} });
  runtime.connection(true); runtime.setReady(true); runtime.receive(state({ generation: 2, phase: "running" }), binding); await flush();
  runtime.reject("binding_stale", { runId: binding.runId, generation: 1 });
  assert.equal(context?.signal.aborted, false); assert.equal(runtime.getError(), null);
  runtime.reject("binding_stale", { runId: binding.runId, generation: 2 });
  assert.equal(context?.signal.aborted, true); runtime.disconnect();
});

test("ordinary play on an older Runtime does not show a demo error until requested", () => {
  for (const role of ["display", "controller"] as const) {
    let errors = 0;
    const runtime = new DemoRuntime(role, () => binding, () => true);
    runtime.onError(() => errors++);
    if (role === "display") runtime.setDesired(false);
    runtime.connection(false);
    assert.equal(runtime.getError(), null); assert.equal(errors, 0); runtime.disconnect();
  }
});

for (const result of ["resolve", "reject"] as const) {
  test(`a cancelled prepare must ${result} and release late resources before the next generation prepares`, async () => {
    const pendingPrepare = deferred(), pendingStop = deferred();
    const calls: string[] = [], resources = new Set<number>(), sent: DemoAction[] = [];
    let preparing: DemoContext | undefined;
    let owner = 0;
    const runtime = new DemoRuntime("controller", () => binding, action => { sent.push(action); return true; });
    runtime.registerDriver({
      contractVersion: 1,
      async prepare(context) {
        owner = context.generation;
        calls.push(`prepare:${owner}`);
        if (owner === 1) { preparing = context; await pendingPrepare.promise; }
        resources.add(context.generation);
        calls.push(`acquired:${context.generation}`);
        if (context.generation === 1 && result === "reject") throw new Error("late preparation failure");
      },
      async run() { assert.fail("running has not been admitted"); },
      async stop() {
        const releasedOwner = owner;
        calls.push(`stop:${releasedOwner}`);
        if (releasedOwner === 1) await pendingStop.promise;
        resources.delete(releasedOwner);
        calls.push(`released:${releasedOwner}`);
      }
    });
    runtime.connection(true); runtime.setReady(true); runtime.receive(state(), binding); await flush();
    runtime.receive(state({ generation: 2, revision: 2 }), binding); await flush();
    assert.equal(preparing?.signal.aborted, true);
    assert.deepEqual(calls, ["prepare:1"]);

    pendingPrepare.resolve(); await flush();
    assert.deepEqual(calls, ["prepare:1", "acquired:1", "stop:1"]);
    assert.deepEqual([...resources], [1]);
    assert.equal(sent.length, 0);

    pendingStop.resolve(); await flush();
    assert.deepEqual(calls, ["prepare:1", "acquired:1", "stop:1", "released:1", "prepare:2", "acquired:2"]);
    assert.deepEqual([...resources], [2]);
    assert.deepEqual(sent, [{ type: "demo.surface.ready", generation: 2, prepared: true }]);
    assert.equal(runtime.getError(), null);
    runtime.disconnect(); await flush(); assert.equal(resources.size, 0);
  });
}

test("a preparation that misses the cleanup deadline blocks future generations and is still released if it settles later", async t => {
  t.mock.timers.enable({ apis: ["setTimeout"] });
  const pendingPrepare = deferred(), resources = new Set<number>(), sent: DemoAction[] = [];
  let prepares = 0, stops = 0;
  const runtime = new DemoRuntime("controller", () => binding, action => { sent.push(action); return true; });
  runtime.registerDriver({
    contractVersion: 1,
    async prepare(context) { prepares++; await pendingPrepare.promise; resources.add(context.generation); },
    async run() { assert.fail("timed out driver must never run"); },
    stop() { stops++; resources.clear(); }
  });
  runtime.connection(true); runtime.setReady(true); runtime.receive(state(), binding); await flush();
  runtime.receive(state({ generation: 2, revision: 2 }), binding); await flush();
  t.mock.timers.tick(4999); await flush();
  assert.equal(runtime.getError(), null); assert.equal(prepares, 1); assert.equal(stops, 0);
  t.mock.timers.tick(1); await flush();
  assert.equal(runtime.getError(), "demo_stop_failed");
  assert.equal(sent.filter(action => action.type === "demo.fail").length, 1);
  assert.equal(sent.some(action => action.prepared === true), false);

  pendingPrepare.resolve(); await flush();
  assert.equal(stops, 1); assert.equal(resources.size, 0);
  runtime.receive(state({ generation: 3, revision: 3 }), binding); await flush();
  assert.equal(prepares, 1); assert.equal(stops, 1);
  assert.equal(runtime.getError(), "demo_stop_failed"); runtime.disconnect(); await flush();
});

test("preparation settlement and stop share one cleanup deadline", async t => {
  t.mock.timers.enable({ apis: ["setTimeout"] });
  const pendingPrepare = deferred(), pendingStop = deferred();
  let prepares = 0, stops = 0;
  const runtime = new DemoRuntime("controller", () => binding, () => true);
  runtime.registerDriver({ contractVersion: 1,
    async prepare() { prepares++; await pendingPrepare.promise; },
    async run() {}, async stop() { stops++; await pendingStop.promise; } });
  runtime.connection(true); runtime.setReady(true); runtime.receive(state(), binding); await flush();
  runtime.receive(state({ generation: 2, revision: 2 }), binding); await flush();
  t.mock.timers.tick(4000); pendingPrepare.resolve(); await flush();
  assert.equal(stops, 1); assert.equal(runtime.getError(), null);
  t.mock.timers.tick(999); await flush(); assert.equal(runtime.getError(), null);
  t.mock.timers.tick(1); await flush(); assert.equal(runtime.getError(), "demo_stop_failed");
  pendingStop.resolve(); await flush();
  assert.equal(prepares, 1); runtime.disconnect(); await flush();
});

test("unmount retains the old driver's preparation and cleanup ownership before a replacement driver starts", async () => {
  const pendingPrepare = deferred(), calls: string[] = [];
  const runtime = new DemoRuntime("controller", () => binding, () => true);
  const remove = runtime.registerDriver({ contractVersion: 1,
    async prepare() { calls.push("old:prepare"); await pendingPrepare.promise; calls.push("old:prepared"); },
    async run() {}, stop() { calls.push("old:stop"); } });
  runtime.connection(true); runtime.setReady(true); runtime.receive(state(), binding); await flush();
  remove();
  runtime.registerDriver({ contractVersion: 1, async prepare() { calls.push("new:prepare"); }, async run() {}, stop() { calls.push("new:stop"); } });
  await flush(); assert.deepEqual(calls, ["old:prepare"]);
  pendingPrepare.resolve(); await flush();
  assert.deepEqual(calls, ["old:prepare", "old:prepared", "old:stop", "new:prepare"]);
  runtime.disconnect(); await flush(); assert.equal(calls.at(-1), "new:stop");
});
