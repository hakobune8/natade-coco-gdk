export type { GameDemoClientMessage } from "./generated/game-sync-types.js";
export { validateGameDemoClientMessage } from "./generated/game-sync-validators.js";
/** Additive demo contract over the authenticated game-sync connection. */
export const DEMO_OFFER = "natadecoco.demo.v1";
export interface DemoManifest { contractVersion: number; maxDurationSeconds?: number }
export type DemoPhase = "off" | "preparing" | "running" | "completed" | "failed";
export interface DemoSnapshot {
  contractVersion: 1;
  sessionId: string;
  gameId: string;
  runId: string;
  enabled: boolean;
  generation: number;
  revision: number;
  phase: DemoPhase;
  errorCode: string | null;
  displayPrepared: boolean;
  controllers: readonly { playerId: string; slot: number; prepared: boolean }[];
}
export interface DemoContext {
  readonly sessionId: string;
  readonly gameId: string;
  readonly runId: string;
  readonly generation: number;
  readonly role: "display" | "controller";
  readonly slot: number | null;
  readonly signal: AbortSignal;
  /** Abortable delay; game drivers must also cancel their own listeners/timers. */
  sleep(milliseconds: number): Promise<void>;
  /** Fence an ordinary game action to this running, synchronized generation. */
  perform<T>(action: () => T): T | undefined;
}
export type DemoStopReason = "off" | "disconnected" | "sync-lost" | "replaced" | "completed" | "failed" | "unmounted";
export interface GameDemoDriver {
  readonly contractVersion: 1;
  /** Prepare from the existing board. On abort, settle without waiting for stop:
   * the SDK waits for preparation to settle before calling stop and admitting
   * another generation. Never create another session or reset the board. */
  prepare(context: DemoContext): void | Promise<void>;
  /** Resolving the Display driver completes demo; Controller resolution is local. */
  run(context: DemoContext): Promise<void>;
  /** Release this generation's resources, including those acquired by a late
   * prepare. Called after prepare settles; must be idempotent. */
  stop(reason: DemoStopReason): void | Promise<void>;
}
export interface DemoClient {
  getState(): Readonly<DemoSnapshot> | null;
  onState(listener: (state: Readonly<DemoSnapshot> | null) => void): () => void;
  getError(): string | null;
  onError(listener: (code: string) => void): () => void;
  registerDriver(driver: GameDemoDriver): () => void;
  missingDriver(): void;
}
export interface DemoBinding { sessionId: string; gameId: string; runId: string }
export interface DemoAction { type: "demo.mode.set" | "demo.surface.ready" | "demo.complete" | "demo.fail"; generation: number; enabled?: boolean; prepared?: boolean; errorCode?: string }
interface DemoTask {
  controller: AbortController;
  key: string;
  driver: GameDemoDriver;
  preparation: Promise<void>;
  started: boolean;
  prepared: boolean;
  running: boolean;
}
const identifier = (value: unknown): value is string => typeof value === "string" && /^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/.test(value);
const counter = (value: unknown): value is number => Number.isSafeInteger(value) && (value as number) >= 0;
const object = (value: unknown): value is Record<string, unknown> => !!value && typeof value === "object" && !Array.isArray(value);
const closed = (value: Record<string, unknown>, keys: string[]): boolean => Object.keys(value).every(key => keys.includes(key)) && keys.every(key => Object.hasOwn(value, key));

export function parseDemoQuery(query: string): boolean {
  const values = new URLSearchParams(query).getAll("demo");
  if (values.length === 0) return false;
  if (values.length !== 1 || !["0", "1"].includes(values[0]!)) throw new TypeError("demo must be exactly 0 or 1");
  return values[0] === "1";
}
export function isDemoSnapshot(value: unknown, binding: DemoBinding): value is DemoSnapshot {
  if (!object(value) || !closed(value, ["contractVersion", "sessionId", "gameId", "runId", "enabled", "generation", "revision", "phase", "errorCode", "displayPrepared", "controllers"])) return false;
  if (value.contractVersion !== 1 || value.sessionId !== binding.sessionId || value.gameId !== binding.gameId || value.runId !== binding.runId || !identifier(value.runId) || !counter(value.generation) || !counter(value.revision) || typeof value.enabled !== "boolean" || typeof value.displayPrepared !== "boolean" || !["off", "preparing", "running", "completed", "failed"].includes(value.phase as string)) return false;
  if (value.errorCode !== null && (typeof value.errorCode !== "string" || !/^[a-z][a-z0-9_]{0,63}$/.test(value.errorCode))) return false;
  if (value.enabled === (value.phase === "off") || !Array.isArray(value.controllers) || value.controllers.length > 8) return false;
  const players = new Set<string>(), slots = new Set<number>();
  return value.controllers.every(item => {
    if (!object(item) || !closed(item, ["playerId", "slot", "prepared"]) || !identifier(item.playerId) || !Number.isInteger(item.slot) || (item.slot as number) < 1 || (item.slot as number) > 8 || typeof item.prepared !== "boolean" || players.has(item.playerId) || slots.has(item.slot as number)) return false;
    players.add(item.playerId); slots.add(item.slot as number); return true;
  });
}

/** Owns cancellation/fencing, while the game owns all actual automatic input. */
export class DemoRuntime implements DemoClient {
  private state: DemoSnapshot | null = null;
  private error: string | null = null;
  private stateListeners = new Set<(state: Readonly<DemoSnapshot> | null) => void>();
  private errorListeners = new Set<(code: string) => void>();
  private driver: GameDemoDriver | undefined;
  private task: DemoTask | undefined;
  private stopping: Promise<void> = Promise.resolve();
  private cleanupFailed = false;
  private ready = false;
  private connected = false;
  private negotiated = false;
  private observed = false;
  private requested: string | undefined;
  private desired: boolean | undefined;
  private mounted = false;
  private rejected = false;
  private configurationError: string | undefined;
  private finishedKey: string | undefined;
  constructor(private readonly role: "display" | "controller", private readonly binding: () => DemoBinding | null,
    private readonly send: (action: DemoAction) => boolean, private readonly neutral: () => void = () => {}, private readonly slot: () => number | null = () => null) {}
  getState(): Readonly<DemoSnapshot> | null { return this.state; }
  getError(): string | null { return this.error; }
  onState(listener: (state: Readonly<DemoSnapshot> | null) => void): () => void { this.stateListeners.add(listener); return () => this.stateListeners.delete(listener); }
  onError(listener: (code: string) => void): () => void { this.errorListeners.add(listener); return () => this.errorListeners.delete(listener); }
  reportError(code: string): void { this.error = code; for (const listener of this.errorListeners) { try { listener(code); } catch { /* isolate observers */ } } }
  invalidConfiguration(code: string): void { this.configurationError = code; this.reportError(code); this.cancel("failed"); }
  reject(code: string, request?: { runId: string; generation: number }): void {
    if (code === "binding_stale" && this.state && request && (request.runId !== this.state.runId || request.generation < this.state.generation || ["completed", "failed"].includes(this.state.phase))) return;
    this.rejected = true; this.reportError(code); this.cancel("failed");
  }
  setDesired(enabled: boolean): void { if (this.role !== "display") throw new TypeError("only Display selects demo mode"); this.desired = enabled; this.tick(); }
  connection(supported: boolean): void { this.state = null; this.rejected = false; this.ready = false; this.observed = false; this.connected = true; this.negotiated = supported; this.requested = undefined; if (!supported && this.desired === true) this.reportError("demo_contract_unsupported"); this.tick(); }
  disconnect(): void { this.connected = false; this.ready = false; this.requested = undefined; this.cancel("disconnected"); }
  setReady(ready: boolean, reportLoss = true): void {
    if (reportLoss && this.ready && !ready && this.task && this.connected && this.state?.enabled) this.dispatch({ type: "demo.surface.ready", generation: this.state.generation, prepared: false });
    this.ready = ready;
    if (!ready) this.cancel("sync-lost");
    this.tick();
  }
  receive(value: unknown, binding: DemoBinding): void {
    if (value !== null && !isDemoSnapshot(value, binding)) { this.reject("demo_snapshot_invalid"); return; }
    const state = value as DemoSnapshot | null;
    if (state && this.state?.runId === state.runId && state.revision <= this.state.revision) return;
    this.observed = true;
    this.rejected = false;
    this.state = state ? Object.freeze({ ...state, controllers: Object.freeze(state.controllers.map(item => Object.freeze({ ...item }))) }) : null;
    this.error = this.configurationError ?? state?.errorCode ?? null;
    for (const listener of this.stateListeners) { try { listener(this.state); } catch { /* isolate observers */ } }
    if (state?.errorCode) this.reportError(state.errorCode);
    this.tick();
  }
  registerDriver(driver: GameDemoDriver): () => void {
    if (this.driver) throw new TypeError("demo driver already registered");
    if (driver.contractVersion !== 1 || typeof driver.prepare !== "function" || typeof driver.run !== "function" || typeof driver.stop !== "function") { this.mounted = true; this.fail("demo_driver_unsupported"); return () => {}; }
    this.driver = driver; this.mounted = true; this.tick();
    return () => { if (this.driver !== driver) return; this.cancel("unmounted"); this.driver = undefined; this.mounted = false; };
  }
  missingDriver(): void { this.mounted = true; this.tick(); }
  private cancel(reason: DemoStopReason): void {
    const task = this.task;
    if (!task) return;
    this.task = undefined; task.controller.abort(); this.neutral();
    // Keep ownership of an in-flight prepare until it settles, then release its
    // resources before admitting another generation. The deadline covers both
    // preparation settlement and stop. Even after timeout, late cleanup runs,
    // while the rejected barrier prevents any future prepare on this client.
    this.stopping = this.stopping.then(async () => {
      const cleanup = task.preparation.catch(() => {}).then(async () => {
        if (task.started) await task.driver.stop(reason);
      });
      let timer: ReturnType<typeof setTimeout> | undefined;
      try { await Promise.race([cleanup, new Promise<never>((_, reject) => { timer = setTimeout(() => reject(new Error("demo stop timeout")), 5000); })]); }
      finally { if (timer !== undefined) clearTimeout(timer); }
    });
    void this.stopping.catch(() => {
      if (this.cleanupFailed) return;
      this.cleanupFailed = true;
      this.fail("demo_stop_failed");
    });
  }
  private dispatch(action: DemoAction): boolean {
    try { return this.send(action); }
    catch { this.reportError("demo_transport_failed"); return false; }
  }
  private fail(code: string): void {
    if (this.state) this.finishedKey = `${this.state.runId}:${this.state.generation}`;
    this.reportError(code);
    if (this.connected && this.state?.enabled && !["completed", "failed"].includes(this.state.phase)) this.dispatch({ type: "demo.fail", generation: this.state.generation, errorCode: code });
    this.cancel("failed");
  }
  private tick(): void {
    const binding = this.binding();
    if (!binding || !this.connected || !this.negotiated || !this.observed || this.rejected) return;
    const state = this.state?.runId === binding.runId ? this.state : null;
    if (this.role === "display" && this.ready && this.desired !== undefined && (state?.enabled ?? false) !== this.desired && this.requested !== binding.runId) {
      if (this.dispatch({ type: "demo.mode.set", generation: state?.generation ?? 0, enabled: this.desired })) this.requested = binding.runId;
    }
    if (!state?.enabled || state.phase === "off" || state.phase === "completed" || state.phase === "failed") { this.cancel(state?.phase === "completed" ? "completed" : state?.phase === "failed" ? "failed" : "off"); return; }
    if (!this.ready) return;
    const key = `${state.runId}:${state.generation}`;
    if (this.finishedKey === key) return;
    if (this.cleanupFailed) { this.fail("demo_stop_failed"); return; }
    if (this.configurationError) { this.fail(this.configurationError); return; }
    if (!this.driver) { if (this.mounted) this.fail("demo_driver_missing"); return; }
    if (this.task && this.task.key !== key) this.cancel("replaced");
    if (!this.task) {
      const controller = new AbortController();
      const task: DemoTask = { controller, key, driver: this.driver, preparation: Promise.resolve(), started: false, prepared: false, running: false }; this.task = task;
      const context: DemoContext = { ...binding, generation: state.generation, role: this.role, slot: this.slot(), signal: controller.signal,
        perform: action => {
          if (this.task !== task || controller.signal.aborted || !this.ready || !this.connected || this.state?.phase !== "running" || this.state.generation !== state.generation || this.binding()?.runId !== binding.runId) return undefined;
          return action();
        },
        sleep: milliseconds => new Promise<void>((resolve, reject) => {
          if (!Number.isFinite(milliseconds) || milliseconds < 0) { reject(new TypeError("invalid demo delay")); return; }
          const signal = controller.signal;
          if (signal.aborted) { reject(signal.reason); return; }
          const abort = () => { clearTimeout(timer); reject(signal.reason); };
          const timer = setTimeout(() => { signal.removeEventListener("abort", abort); resolve(); }, milliseconds);
          signal.addEventListener("abort", abort, { once: true });
        }) };
      task.preparation = this.stopping.then(async () => {
        if (this.task !== task) return;
        task.started = true;
        await task.driver.prepare(context);
        if (this.task !== task) return;
        task.prepared = true;
        this.dispatch({ type: "demo.surface.ready", generation: state.generation, prepared: true });
        this.tick();
      });
      void task.preparation.catch(() => { if (this.task === task) this.fail(this.cleanupFailed ? "demo_stop_failed" : "demo_prepare_failed"); });
      // Keep context local to this generation, including after async prepare.
      this.contexts.set(task, context);
    }
    const task = this.task;
    if (task?.prepared && !task.running && state.phase === "running") {
      task.running = true;
      const driver = task.driver, context = this.contexts.get(task)!;
      void Promise.resolve().then(() => { if (this.task === task) return driver.run(context); }).then(() => {
        if (this.task !== task) return;
        if (this.role === "display") this.dispatch({ type: "demo.complete", generation: state.generation });
        else { this.finishedKey = key; this.cancel("completed"); }
      }).catch(() => { if (this.task === task) this.fail("demo_run_failed"); });
    }
  }
  private contexts = new WeakMap<object, DemoContext>();
}
