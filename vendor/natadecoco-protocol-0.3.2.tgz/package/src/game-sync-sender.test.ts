import assert from "node:assert/strict";
import { test } from "node:test";
import {
  GameRequestSender,
  validateGameSyncDocument,
  type GameSyncServerMessage,
  type GameSyncRole,
} from "./game-sync.js";
function harness(role: GameSyncRole = "display") {
  const frames: string[] = [],
    timers = new Map<number, () => void>(),
    due = new Map<number, number>(),
    errors: string[] = [];
  let now = 0;
  let id = 0,
    timer = 0;
  const sender = new GameRequestSender({
    binding: {
      sessionId: "s",
      gameId: "g",
      connectionId: "c",
      epoch: "e",
      scope: { kind: "run", runId: "r" },
      role,
    },
    send: (frame) => {
      frames.push(frame);
      return true;
    },
    newId: () => `id-${id++}`,
    now: () => now,
    onTransportError: (error) => errors.push(error.code),
    setTimeout: (callback, delay) => {
      timers.set(++timer, callback);
      due.set(timer, now + delay);
      return timer as unknown as ReturnType<typeof setTimeout>;
    },
    clearTimeout: (handle) => {
      timers.delete(handle as unknown as number);
      due.delete(handle as unknown as number);
    },
    onStateError: (error) => errors.push(error.code),
  });
  const reply = (
    type: string,
    requestMessageId: string,
    extra: Record<string, unknown> = {},
  ) =>
    ({
      protocolVersion: "1.0",
      gameSyncVersion: 1,
      type,
      messageId: `reply-${id++}`,
      sessionId: "s",
      gameId: "g",
      connectionId: "c",
      epoch: "e",
      sequence: 0,
      scope: { runId: "r", kind: "run" },
      requestMessageId,
      ...extra,
    }) as GameSyncServerMessage;
  return {
    sender,
    frames,
    timers,
    errors,
    reply,
    advance: (milliseconds: number) => {
      now += milliseconds;
    },
    runNext: () => {
      const next = [...timers.keys()].sort(
        (a, b) => due.get(a)! - due.get(b)!,
      )[0];
      assert.ok(next);
      now = due.get(next)!;
      const callback = timers.get(next)!;
      timers.delete(next);
      due.delete(next);
      callback();
    },
    now: () => now,
  };
}
test("publication frame accounting and end receipt are correlated exactly", async () => {
  const h = harness();
  const entries = Array.from({ length: 3 }, (_, i) => ({
    operation: "put" as const,
    name: `view-${i}`,
    target: { kind: "all-controllers" as const },
    payload: "界".repeat(20000),
  }));
  const promise = h.sender.publish(entries, 4),
    frames = h.frames.map((frame) => JSON.parse(frame));
  const begin = frames[0],
    parts = frames.filter((frame) => frame.type === "game.publication.part"),
    end = frames.at(-1);
  assert.equal(begin.partCount, parts.length);
  assert.ok(parts.length > 1);
  assert.equal(
    begin.totalBytes,
    h.frames
      .filter((frame) => JSON.parse(frame).type === "game.publication.part")
      .reduce(
        (total, frame) => total + new TextEncoder().encode(frame).byteLength,
        0,
      ),
  );
  for (const frame of frames)
    assert.equal(validateGameSyncDocument("wire", frame, "display").ok, true);
  h.sender.receive(
    h.reply("game.receipt", end.messageId, {
      publicationId: begin.publicationId,
      publicationRevision: 7,
      gatewayAcceptedAt: 123,
    }),
  );
  assert.deepEqual(await promise, { revision: 7, checkpointRevision: 4 });
  assert.equal(h.timers.size, 0);
});
test("a rejection of begin settles the whole publication immediately", async () => {
  const h = harness(),
    promise = h.sender.publish(
      [
        {
          operation: "put",
          name: "view",
          target: { kind: "all-controllers" },
          payload: {},
        },
      ],
      0,
    );
  const begin = JSON.parse(h.frames[0]!);
  const rejected = assert.rejects(
    promise,
    (error: unknown) => (error as { code: string }).code === "rate_limited",
  );
  h.sender.receive(
    h.reply("game.rejected", begin.messageId, {
      publicationId: begin.publicationId,
      code: "rate_limited",
      retryable: true,
    }),
  );
  await rejected;
  assert.equal(h.timers.size, 0);
});
test("pending receipts are bounded and timeout/disconnect reject instead of replaying", async () => {
  const h = harness("controller"),
    pending = Array.from({ length: 64 }, () =>
      h.sender
        .event("hit", {})
        .catch((error) => (error as { code: string }).code),
    );
  await assert.rejects(
    h.sender.event("hit", {}),
    (error: unknown) => (error as { code: string }).code === "queue_full",
  );
  assert.equal(h.frames.length, 10); // The rest remain bounded behind the event rate limit.
  const callbacks = [...h.timers.values()];
  h.timers.clear();
  for (const callback of callbacks) callback();
  assert.ok(
    (await Promise.all(pending)).every((code) => code === "receipt_timeout"),
  );
  const promise = h.sender.event("hit", {});
  const rejected = assert.rejects(promise);
  h.sender.disconnect();
  await rejected;
  assert.equal(h.timers.size, 0);
  assert.equal(h.frames.length, 10);
});
test("invalid publication data is rejected before sending", async () => {
  const h = harness();
  await assert.rejects(
    h.sender.publish(
      [
        {
          operation: "put",
          name: "platform.input",
          target: { kind: "all-controllers" },
          payload: {},
        },
      ],
      0,
    ),
  );
  await assert.rejects(
    h.sender.publish(
      [
        {
          operation: "put",
          name: "view",
          target: { kind: "all-controllers" },
          payload: "x".repeat(65537),
        },
      ],
      0,
    ),
  );
  assert.equal(h.frames.length, 0);
});

test("a large publication stays inside Gateway byte rate and burst while preserving its complete frame accounting", async () => {
  const h = harness(),
    entries = Array.from({ length: 128 }, (_, i) => ({
      operation: "put" as const,
      name: `view-${i}`,
      target: { kind: "all-controllers" as const },
      payload: "x".repeat(15000),
    }));
  const promise = h.sender.publish(entries, 0),
    begin = JSON.parse(h.frames[0]!);
  let tokens = 512 << 10,
    at = 0,
    observed = 0;
  const inspect = () => {
    tokens = Math.min(512 << 10, tokens + ((h.now() - at) * (2 << 20)) / 1000);
    at = h.now();
    while (observed < h.frames.length) {
      const size = new TextEncoder().encode(h.frames[observed++]!).byteLength;
      assert.ok(size <= tokens + 0.001, "Gateway byte bucket exceeded");
      tokens -= size;
    }
  };
  inspect();
  assert.equal(
    h.frames.some((frame) => JSON.parse(frame).type === "game.publication.end"),
    false,
  );
  while (
    !h.frames.some((frame) => JSON.parse(frame).type === "game.publication.end")
  ) {
    h.runNext();
    inspect();
    assert.ok(h.now() < 5000);
  }
  const partFrames = h.frames.filter(
    (frame) => JSON.parse(frame).type === "game.publication.part",
  );
  assert.equal(
    partFrames.reduce(
      (sum, frame) => sum + new TextEncoder().encode(frame).byteLength,
      0,
    ),
    begin.totalBytes,
  );
  assert.equal(partFrames.length, begin.partCount);
  const end = JSON.parse(h.frames.at(-1)!);
  h.sender.receive(
    h.reply("game.receipt", end.messageId, {
      publicationId: begin.publicationId,
      publicationRevision: 1,
      gatewayAcceptedAt: 1000,
    }),
  );
  await promise;
  assert.equal(h.timers.size, 0);
});
test("aggregate publication queue is bounded and disconnect drops unsent parts", async () => {
  const h = harness(),
    entries = Array.from({ length: 128 }, (_, i) => ({
      operation: "put" as const,
      name: `view-${i}`,
      target: { kind: "all-controllers" as const },
      payload: "x".repeat(15000),
    }));
  const first = h.sender
    .publish(entries, 0)
    .catch((error) => (error as { code: string }).code);
  const second = h.sender
    .publish(entries, 0)
    .catch((error) => (error as { code: string }).code);
  await assert.rejects(
    h.sender.publish(entries, 0),
    (error: unknown) => (error as { code: string }).code === "queue_full",
  );
  const sent = h.frames.length;
  h.sender.disconnect();
  await Promise.all([first, second]);
  assert.equal(h.timers.size, 0);
  assert.equal(h.frames.length, sent);
});
test("unsent Controller state coalesces per name without accumulating pending Promises or reversing stream order", () => {
  const h = harness("controller");
  for (let i = 0; i < 4; i++)
    assert.ok(h.sender.state(`fill-${i}`, "put", "x".repeat(64000)));
  for (let i = 0; i < 100; i++)
    assert.ok(h.sender.state("latest", "put", "x".repeat(63990) + i));
  assert.ok(h.timers.size <= 6); // Four admitted frames plus one latest intent and a pacing timer.
  while (!h.frames.some((frame) => JSON.parse(frame).name === "latest"))
    h.runNext();
  const states = h.frames.map((frame) => JSON.parse(frame));
  assert.equal(states.filter((frame) => frame.name === "latest").length, 1);
  assert.ok(states.at(-1).payload.endsWith("99"));
  assert.ok(
    states.every(
      (frame, index) =>
        index === 0 || frame.sequence > states[index - 1].sequence,
    ),
  );
  h.sender.disconnect();
  assert.equal(h.timers.size, 0);
});

test("standard input passes paced generic intents without reversing state stream sequences", () => {
  const h = harness("controller");
  for (let i = 0; i < 4; i++)
    h.sender.state(`fill-${i}`, "put", "x".repeat(64000));
  h.sender.state("large", "put", "x".repeat(64000));
  assert.ok(
    h.sender.state("platform.input", "put", { buttons: { a: true } }, true),
  );
  const afterInput = h.frames.map((frame) => JSON.parse(frame));
  assert.equal(afterInput.at(-1).name, "platform.input");
  while (!h.frames.some((frame) => JSON.parse(frame).name === "large"))
    h.runNext();
  const states = h.frames.map((frame) => JSON.parse(frame));
  assert.ok(
    states.every(
      (frame, index) =>
        index === 0 || frame.sequence > states[index - 1].sequence,
    ),
  );
  assert.equal(states.filter((frame) => frame.name === "large").length, 1);
  h.sender.disconnect();
});

test("next publication begin waits for the previous admission receipt", async () => {
  const h = harness(),
    entry = {
      operation: "put" as const,
      name: "view",
      target: { kind: "all-controllers" as const },
      payload: {},
    };
  const first = h.sender.publish([entry], 0),
    firstEnd = JSON.parse(h.frames.at(-1)!);
  const second = h.sender.publish([entry], 1);
  assert.equal(
    h.frames.filter(
      (frame) => JSON.parse(frame).type === "game.publication.begin",
    ).length,
    1,
  );
  h.sender.receive(
    h.reply("game.receipt", firstEnd.messageId, {
      publicationId: firstEnd.publicationId,
      publicationRevision: 1,
      gatewayAcceptedAt: 1,
    }),
  );
  await first;
  assert.equal(
    h.frames.filter(
      (frame) => JSON.parse(frame).type === "game.publication.begin",
    ).length,
    2,
  );
  const secondEnd = JSON.parse(h.frames.at(-1)!);
  h.sender.receive(
    h.reply("game.receipt", secondEnd.messageId, {
      publicationId: secondEnd.publicationId,
      publicationRevision: 2,
      gatewayAcceptedAt: 2,
    }),
  );
  await second;
  assert.equal(h.timers.size, 0);
});

test("publication entry admission is paced at end against the Display count burst and rate", async () => {
  const h = harness(),
    entries = Array.from({ length: 128 }, (_, i) => ({
      operation: "put" as const,
      name: `view-${i}`,
      target: { kind: "all-controllers" as const },
      payload: i,
    }));
  const first = h.sender.publish(entries, 0),
    firstEnd = JSON.parse(h.frames.at(-1)!);
  h.sender.receive(
    h.reply("game.receipt", firstEnd.messageId, {
      publicationId: firstEnd.publicationId,
      publicationRevision: 1,
      gatewayAcceptedAt: 0,
    }),
  );
  await first;
  const second = h.sender.publish(entries, 1);
  assert.equal(
    h.frames.filter(
      (frame) => JSON.parse(frame).type === "game.publication.end",
    ).length,
    1,
  );
  assert.equal(JSON.parse(h.frames.at(-1)!).type, "game.publication.part");
  h.runNext();
  assert.ok(h.now() >= 1066 && h.now() <= 1067);
  const secondEnd = JSON.parse(h.frames.at(-1)!);
  assert.equal(secondEnd.type, "game.publication.end");
  h.sender.receive(
    h.reply("game.receipt", secondEnd.messageId, {
      publicationId: secondEnd.publicationId,
      publicationRevision: 2,
      gatewayAcceptedAt: h.now(),
    }),
  );
  await second;
  assert.equal(h.timers.size, 0);
});

test("Controller event count pacing leaves standard state input responsive", async () => {
  const h = harness("controller"),
    events = Array.from({ length: 12 }, () => h.sender.event("tap", {}));
  assert.equal(h.frames.length, 10);
  h.sender.state("platform.input", "put", { buttons: { left: true } }, true);
  assert.equal(JSON.parse(h.frames.at(-1)!).name, "platform.input");
  h.runNext();
  assert.equal(h.now(), 50);
  h.runNext();
  assert.equal(h.now(), 100);
  assert.equal(
    h.frames.filter((frame) => JSON.parse(frame).type === "game.event").length,
    12,
  );
  for (const raw of h.frames) {
    const frame = JSON.parse(raw);
    h.sender.receive(
      h.reply("game.receipt", frame.messageId, {
        publicationId: null,
        publicationRevision: null,
        gatewayAcceptedAt: h.now(),
      }),
    );
  }
  await Promise.all(events);
  assert.equal(h.timers.size, 0);
});
