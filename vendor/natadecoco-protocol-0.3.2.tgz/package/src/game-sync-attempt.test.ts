import assert from "node:assert/strict";
import { test } from "node:test";
import { GameSyncAttemptGate, type SyncAttempt, type SyncAttemptBinding } from "./game-sync-attempt.js";

const initial: SyncAttemptBinding = { sessionId: "session", runId: "run", connectionId: "connection", epoch: "epoch" };
test("only the latest opaque attempt accepts a report once, without retaining a game payload", () => {
  const gate = new GameSyncAttemptGate(() => initial);
  const first = gate.begin(), second = gate.begin();
  assert.equal(Object.isFrozen(second), true);
  assert.deepEqual(gate.accept(first, { state: "ready" }), { accepted: false });
  assert.deepEqual(gate.accept(JSON.parse(JSON.stringify(second)) as SyncAttempt, { state: "ready" }), { accepted: false });
  assert.deepEqual(gate.accept(second, { state: "ready", revision: "revision-2" }), { accepted: true });
  assert.equal(gate.getReport()?.revision, "revision-2");
  assert.deepEqual(gate.accept(second, { state: "failed" }), { accepted: false });
  const third = gate.begin();
  assert.equal(gate.getReport(), undefined);
  gate.invalidate();
  assert.deepEqual(gate.accept(third, { state: "ready" }), { accepted: false });
});
test("session, run, connection, authority epoch and disconnect fence both reports and readiness", () => {
  for (const changed of [{ ...initial, sessionId: "other" }, { ...initial, runId: "next" }, { ...initial, connectionId: "next" }, { ...initial, epoch: "next" }, undefined]) {
    let current: SyncAttemptBinding | undefined = initial;
    const gate = new GameSyncAttemptGate(() => current);
    const attempt = gate.begin();
    current = changed;
    assert.deepEqual(gate.accept(attempt, { state: "ready" }), { accepted: false });
    assert.equal(gate.getReport(), undefined);
    current = initial;
    gate.accept(attempt, { state: "ready" });
    current = changed;
    assert.equal(gate.getReport(), undefined);
  }
});
test("unbound begin and invalid current reports cannot establish readiness", () => {
  assert.throws(() => new GameSyncAttemptGate(() => undefined).begin(), { code: "game_sync_not_ready" });
  const gate = new GameSyncAttemptGate(() => initial), attempt = gate.begin();
  assert.throws(() => gate.accept(attempt, { state: "ready", revision: Infinity }), { code: "payload_invalid" });
  assert.equal(gate.getReport(), undefined);
  assert.deepEqual(gate.accept(attempt, { state: "failed", reason: "game_api_failed" }), { accepted: true });
  assert.equal(gate.getReport()?.state, "failed");
});
