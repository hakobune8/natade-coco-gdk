import type { JsonValue } from "./index.js";
import {
  encodeGameSyncDocument,
  validateGameSyncDocument,
  GAME_SYNC_LIMITS,
  type GameSyncClientMessage,
  type GameSyncServerMessage,
  type GameSyncTarget,
  type GameDeliveryBinding,
  type GameSyncValidationCode,
} from "./game-sync.js";
export interface Receipt {
  messageId: string;
  gatewayAcceptedAt: number;
}
export interface Publication {
  revision: number;
  checkpointRevision: number | null;
}
export type StatePublication =
  | {
      operation: "put";
      name: string;
      target: GameSyncTarget;
      payload: JsonValue;
    }
  | { operation: "clear"; name: string; target: GameSyncTarget };
export class GameSyncError extends Error {
  constructor(
    public readonly code: string,
    public readonly retryable: boolean,
  ) {
    super(code);
    this.name = "GameSyncError";
  }
}
export interface GameRequestSenderOptions {
  binding: GameDeliveryBinding;
  send(frame: string): boolean;
  newId(): string;
  now(): number;
  onTransportError(error: GameSyncError): void;
  setTimeout(
    callback: () => void,
    milliseconds: number,
  ): ReturnType<typeof setTimeout>;
  clearTimeout(handle: ReturnType<typeof setTimeout>): void;
  onStateError(error: GameSyncError): void;
}
type Accepted = Receipt & { publicationRevision: number | null };
interface Pending {
  publicationId: string | null;
  messageIds: Set<string>;
  accepted(receipt: Accepted): void;
  failed(error: GameSyncError): void;
  timer: ReturnType<typeof setTimeout>;
  stateName?: string;
  stateValue?: { operation: "put" | "clear"; payload?: JsonValue };
  sentFrames: number;
}
interface QueuedFrame {
  requestId: string;
  frame: string;
  bytes: number;
  event: boolean;
  stateUnits: number;
}
/** One bounded receipt boundary for Controller state/event and Display
 * publications. A receipt proves Gateway admission, never game completion. */
export class GameRequestSender {
  private sequence = 0;
  private eventSequence = 0;
  private stopped = false;
  private readonly pending = new Map<string, Pending>();
  private readonly publications = new Map<string, string>();
  private readonly names = new Map<string, number>();
  private readonly binding: GameDeliveryBinding;
  private queue: QueuedFrame[] = [];
  private queueBytes = 0;
  private activePublication: string | undefined;
  private paceTimer: ReturnType<typeof setTimeout> | undefined;
  private readonly burst: number;
  private readonly byteRate: number;
  private tokens: number;
  private readonly stateBurst: number;
  private readonly stateRate: number;
  private readonly eventBurst: number;
  private readonly eventRate: number;
  private stateTokens: number;
  private eventTokens: number;
  private updatedAt: number;
  constructor(private readonly options: GameRequestSenderOptions) {
    this.binding = structuredClone(options.binding);
    this.burst = this.binding.role === "display" ? 504 << 10 : 256 << 10;
    this.byteRate = this.binding.role === "display" ? 2 << 20 : 1 << 20;
    this.tokens = this.burst;
    this.stateBurst = this.binding.role === "display" ? 128 : 30;
    this.stateRate = this.binding.role === "display" ? 120 : 60;
    this.eventBurst = this.binding.role === "display" ? 30 : 10;
    this.eventRate = this.binding.role === "display" ? 60 : 20;
    this.stateTokens = this.stateBurst;
    this.eventTokens = this.eventBurst;
    this.updatedAt = options.now();
  }
  private envelope(
    type: GameSyncClientMessage["type"],
  ): Record<string, unknown> {
    if (this.sequence >= Number.MAX_SAFE_INTEGER)
      throw new GameSyncError("binding_stale", false);
    return {
      type,
      protocolVersion: "1.0",
      gameSyncVersion: 1,
      messageId: this.options.newId(),
      sessionId: this.binding.sessionId,
      gameId: this.binding.gameId,
      connectionId: this.binding.connectionId,
      epoch: this.binding.epoch,
      scope: this.binding.scope,
      sequence: this.sequence++,
    };
  }
  private encode(value: unknown): string {
    const checked = encodeGameSyncDocument("wire", value, this.binding.role);
    if (!checked.ok) throw new GameSyncError(checked.code, false);
    return checked.value;
  }
  private checkName(name: string, reserved = false): void {
    if (typeof name !== "string")
      throw new GameSyncError("invalid_game_message", false);
    if (
      name.startsWith("platform.") &&
      !(reserved && name === "platform.input")
    )
      throw new GameSyncError("reserved_name", false);
  }
  /** Returns false only for bounded backpressure; the Controller owner retains
   * the latest intent instead of queuing an unbounded Promise per state change. */
  state(
    name: string,
    operation: "put" | "clear",
    payload?: JsonValue,
    reserved = false,
  ): boolean {
    if (this.binding.role !== "controller")
      throw new GameSyncError("role_invalid", false);
    this.checkName(name, reserved);
    const stateSequence = this.names.get(name) ?? 0;
    const envelope = this.envelope(
      operation === "put" ? "game.state.put" : "game.state.clear",
    );
    const frame = this.encode({
      ...envelope,
      name,
      stateSequence,
      ...(operation === "put" ? { payload } : {}),
    });
    if (this.stopped) return false;
    if (!this.names.has(name) && this.names.size >= 16)
      throw new GameSyncError("cache_limit", false);
    // Only unsent state is replaceable. Move its replacement to the tail so
    // the shared state stream remains monotonically ordered across names.
    const previous = [...this.pending].find(
      ([, pending]) => pending.stateName === name && pending.sentFrames === 0,
    );
    const id = envelope.messageId as string;
    const released = previous
      ? this.queue
          .filter((frame) => frame.requestId === previous[0])
          .reduce((sum, frame) => sum + frame.bytes, 0)
      : 0;
    const size = new TextEncoder().encode(frame).byteLength;
    if (
      this.pending.size - (previous ? 1 : 0) >= 64 ||
      this.queueBytes - released + size > GAME_SYNC_LIMITS.gameQueueBytes
    )
      return false;
    // Standard input remains responsive when large generic state is paced.
    // Reissue other unsent latest intents behind it with fresh stream numbers.
    // Reordering encoded frames directly would violate the Gateway sequence.
    const deferred = reserved
      ? [...this.pending].flatMap(([id, pending]) =>
          pending.sentFrames === 0 &&
          pending.stateName !== name &&
          pending.stateName !== undefined &&
          pending.stateValue !== undefined
            ? [{ id, name: pending.stateName, value: pending.stateValue }]
            : [],
        )
      : [];
    for (const intent of deferred) this.remove(intent.id);
    if (previous) this.remove(previous[0]);
    if (
      !this.enqueue(
        id,
        [frame],
        null,
        () => {},
        (error) => this.options.onStateError(error),
        name,
      )
    )
      return false;
    this.names.set(name, stateSequence + 1);
    const pending = this.pending.get(id);
    if (pending && pending.sentFrames === 0) {
      const owned = JSON.parse(frame) as { payload?: JsonValue };
      pending.stateValue =
        operation === "put"
          ? { operation, payload: owned.payload! }
          : { operation };
    }
    for (const intent of deferred)
      this.state(intent.name, intent.value.operation, intent.value.payload);
    return true;
  }
  event(
    name: string,
    payload: JsonValue,
    target?: GameSyncTarget,
  ): Promise<Receipt> {
    try {
      this.checkName(name);
      const envelope = this.envelope("game.event");
      const frame = this.encode({
        ...envelope,
        name,
        eventSequence: this.eventSequence++,
        payload,
        ...(target === undefined ? {} : { target }),
      });
      return this.request(envelope.messageId as string, [frame], null);
    } catch (error) {
      return Promise.reject(error);
    }
  }
  publish(
    entries: readonly StatePublication[],
    checkpointRevision: number | null,
  ): Promise<Publication> {
    return this.publishWithReceipt(entries, checkpointRevision).then(
      (value) => ({
        revision: value.revision,
        checkpointRevision: value.checkpointRevision,
      }),
    );
  }
  publishWithReceipt(
    entries: readonly StatePublication[],
    checkpointRevision: number | null,
  ): Promise<Publication & { receipt: Receipt }> {
    try {
      if (this.binding.role !== "display")
        throw new GameSyncError("role_invalid", false);
      if (entries.length > GAME_SYNC_LIMITS.displayKeysPerRun)
        throw new GameSyncError("cache_limit", false);
      if (entries.length) {
        const shape = validateGameSyncDocument(
          "wire",
          {
            ...this.envelope("game.publication.part"),
            publicationId: "validation",
            partIndex: 0,
            entries,
          },
          "display",
        );
        if (!shape.ok) throw new GameSyncError(shape.code, false);
      }
      const keys = new Set<string>();
      for (const entry of entries) {
        this.checkName(entry.name);
        const key = JSON.stringify([
          entry.target.kind,
          entry.target.kind === "player" ? entry.target.playerId : "",
          entry.name,
        ]);
        if (keys.has(key))
          throw new GameSyncError("publication_conflict", false);
        keys.add(key);
      }
      const publicationId = this.options.newId();
      const begin = this.envelope("game.publication.begin");
      const parts: string[] = [];
      let part = this.envelope("game.publication.part"),
        group: StatePublication[] = [];
      const encodePart = (candidate: readonly StatePublication[]) =>
        this.encode({
          ...part,
          publicationId,
          partIndex: parts.length,
          entries: candidate,
        });
      for (const entry of entries) {
        const candidate = [...group, structuredClone(entry)];
        try {
          encodePart(candidate);
          group = candidate;
        } catch (error) {
          if (
            !(error instanceof GameSyncError) ||
            error.code !== "frame_too_large" ||
            group.length === 0
          )
            throw error;
          parts.push(encodePart(group));
          part = this.envelope("game.publication.part");
          group = [structuredClone(entry)];
          encodePart(group);
        }
      }
      if (group.length) parts.push(encodePart(group));
      const totalBytes = parts.reduce(
        (total, frame) => total + new TextEncoder().encode(frame).byteLength,
        0,
      );
      if (
        parts.length > GAME_SYNC_LIMITS.transferParts ||
        totalBytes > GAME_SYNC_LIMITS.transferBytes
      )
        throw new GameSyncError("transfer_invalid", false);
      const end = this.envelope("game.publication.end");
      const frames = [
        this.encode({
          ...begin,
          publicationId,
          entryCount: entries.length,
          partCount: parts.length,
          totalBytes,
          checkpointRevision,
        }),
        ...parts,
        this.encode({ ...end, publicationId }),
      ];
      return this.request(end.messageId as string, frames, publicationId).then(
        (receipt) => {
          if (receipt.publicationRevision === null)
            throw new GameSyncError("invalid_game_message", false);
          return {
            revision: receipt.publicationRevision,
            checkpointRevision,
            receipt: {
              messageId: receipt.messageId,
              gatewayAcceptedAt: receipt.gatewayAcceptedAt,
            },
          };
        },
      );
    } catch (error) {
      return Promise.reject(error);
    }
  }
  private request(
    messageId: string,
    frames: readonly string[],
    publicationId: string | null,
  ): Promise<Accepted> {
    return new Promise((resolve, reject) => {
      if (!this.enqueue(messageId, frames, publicationId, resolve, reject))
        reject(
          new GameSyncError(
            this.stopped ? "binding_stale" : "queue_full",
            true,
          ),
        );
    });
  }
  private enqueue(
    messageId: string,
    frames: readonly string[],
    publicationId: string | null,
    accepted: (receipt: Accepted) => void,
    failed: (error: GameSyncError) => void,
    stateName?: string,
  ): boolean {
    const decoded = frames.map(
      (frame) => JSON.parse(frame) as { type: string; entryCount?: number },
    );
    const publicationEntries =
      decoded.find((frame) => frame.type === "game.publication.begin")
        ?.entryCount ?? 0;
    const items = frames.map((frame, i) => ({
      requestId: messageId,
      frame,
      bytes: new TextEncoder().encode(frame).byteLength,
      event: decoded[i]!.type === "game.event",
      stateUnits:
        decoded[i]!.type === "game.publication.end"
          ? publicationEntries
          : decoded[i]!.type === "game.state.put" ||
              decoded[i]!.type === "game.state.clear"
            ? 1
            : 0,
    }));
    const size = items.reduce((sum, item) => sum + item.bytes, 0);
    if (
      this.stopped ||
      this.pending.size >= 64 ||
      this.queue.length + items.length > GAME_SYNC_LIMITS.gameQueueFrames ||
      this.queueBytes + size > GAME_SYNC_LIMITS.gameQueueBytes
    )
      return false;
    const timer = this.options.setTimeout(() => {
      const pending = this.remove(messageId);
      pending?.failed(new GameSyncError("receipt_timeout", true));
      if (
        pending?.publicationId !== null &&
        pending?.publicationId !== undefined
      )
        this.transportFailed();
    }, 5000);
    this.pending.set(messageId, {
      publicationId,
      messageIds: new Set(
        frames.map(
          (frame) => (JSON.parse(frame) as { messageId: string }).messageId,
        ),
      ),
      accepted,
      failed,
      timer,
      sentFrames: 0,
      ...(stateName === undefined ? {} : { stateName }),
    });
    if (publicationId !== null) {
      this.publications.set(publicationId, messageId);
      this.activePublication ??= messageId;
    }
    this.queue.push(...items);
    this.queueBytes += size;
    this.flush();
    return true;
  }
  private remove(messageId: string): Pending | undefined {
    const pending = this.pending.get(messageId);
    if (!pending) return undefined;
    this.options.clearTimeout(pending.timer);
    this.pending.delete(messageId);
    if (pending.publicationId !== null)
      this.publications.delete(pending.publicationId);
    if (this.activePublication === messageId)
      this.activePublication = [...this.pending].find(
        ([, value]) => value.publicationId !== null,
      )?.[0];
    this.queue = this.queue.filter((frame) => {
      if (frame.requestId !== messageId) return true;
      this.queueBytes -= frame.bytes;
      return false;
    });
    return pending;
  }
  private flush(): void {
    if (this.paceTimer !== undefined) this.options.clearTimeout(this.paceTimer);
    this.paceTimer = undefined;
    if (this.stopped) return;
    const now = this.options.now();
    const elapsed = Math.max(0, now - this.updatedAt) / 1000;
    this.tokens = Math.min(this.burst, this.tokens + elapsed * this.byteRate);
    this.stateTokens = Math.min(
      this.stateBurst,
      this.stateTokens + elapsed * this.stateRate,
    );
    this.eventTokens = Math.min(
      this.eventBurst,
      this.eventTokens + elapsed * this.eventRate,
    );
    this.updatedAt = now;
    while (this.queue.length) {
      // Events use a separate sequence stream and can pass publication parts.
      const event = this.queue.findIndex((frame) => frame.event);
      const state = this.queue.findIndex((frame) => !frame.event);
      const stateRequest =
        state < 0 ? undefined : this.pending.get(this.queue[state]!.requestId);
      const blockedState =
        stateRequest?.publicationId != null &&
        this.queue[state]!.requestId !== this.activePublication;
      const index =
        event >= 0 && (this.eventTokens >= 1 || state < 0 || blockedState)
          ? event
          : state;
      if (index < 0) return;
      const next = this.queue[index]!;
      const request = this.pending.get(next.requestId);
      if (
        request?.publicationId !== null &&
        request?.publicationId !== undefined &&
        next.requestId !== this.activePublication
      )
        return;
      const countDelay = next.event
        ? Math.max(0, 1 - this.eventTokens) / this.eventRate
        : Math.max(0, next.stateUnits - this.stateTokens) / this.stateRate;
      const byteDelay = Math.max(0, next.bytes - this.tokens) / this.byteRate;
      if (countDelay > 0 || byteDelay > 0) {
        const delay = Math.max(
          1,
          Math.ceil(Math.max(countDelay, byteDelay) * 1000),
        );
        this.paceTimer = this.options.setTimeout(() => this.flush(), delay);
        return;
      }
      this.queue.splice(index, 1);
      this.queueBytes -= next.bytes;
      this.tokens -= next.bytes;
      if (next.event) this.eventTokens--;
      else this.stateTokens -= next.stateUnits;
      const pending = this.pending.get(next.requestId);
      if (!pending) continue;
      pending.sentFrames++;
      delete pending.stateValue;
      try {
        if (!this.options.send(next.frame)) throw new Error("send failed");
      } catch {
        this.transportFailed();
        return;
      }
      if (this.stopped) return;
    }
  }
  private transportFailed(): void {
    const error = new GameSyncError("delivery_unknown", true);
    this.disconnect("binding_stale");
    this.options.onTransportError(error);
  }
  receive(message: GameSyncServerMessage): boolean {
    if (message.type !== "game.receipt" && message.type !== "game.rejected")
      return false;
    if (
      message.sessionId !== this.binding.sessionId ||
      message.gameId !== this.binding.gameId ||
      message.connectionId !== this.binding.connectionId ||
      message.epoch !== this.binding.epoch ||
      message.scope.kind !== this.binding.scope.kind ||
      (message.scope.kind === "run" &&
        this.binding.scope.kind === "run" &&
        message.scope.runId !== this.binding.scope.runId)
    ) {
      this.disconnect("binding_stale");
      return true;
    }
    const checked = validateGameSyncDocument("server-wire", message);
    if (!checked.ok) {
      this.disconnect(checked.code);
      return true;
    }
    const messageId =
      message.type === "game.rejected" && message.publicationId !== null
        ? this.publications.get(message.publicationId)
        : message.requestMessageId;
    const pending =
      messageId === undefined ? undefined : this.pending.get(messageId);
    if (!pending) return true;
    if (!pending.messageIds.has(message.requestMessageId)) {
      this.disconnect("invalid_game_message");
      return true;
    }
    if (message.publicationId !== pending.publicationId) {
      this.disconnect("invalid_game_message");
      return true;
    }
    this.remove(messageId!);
    if (message.type === "game.rejected")
      pending.failed(new GameSyncError(message.code, message.retryable));
    else
      pending.accepted({
        messageId: message.requestMessageId,
        gatewayAcceptedAt: message.gatewayAcceptedAt,
        publicationRevision: message.publicationRevision,
      });
    this.flush();
    return true;
  }
  disconnect(
    code: GameSyncValidationCode | "binding_stale" = "binding_stale",
  ): void {
    this.stopped = true;
    for (const pending of this.pending.values()) {
      this.options.clearTimeout(pending.timer);
      pending.failed(new GameSyncError(code, true));
    }
    this.pending.clear();
    this.publications.clear();
    if (this.paceTimer !== undefined) this.options.clearTimeout(this.paceTimer);
    this.paceTimer = undefined;
    this.activePublication = undefined;
    this.queue = [];
    this.queueBytes = 0;
  }
}
