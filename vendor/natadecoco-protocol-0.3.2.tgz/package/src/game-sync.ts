import type { JsonValue } from "./index.js";
import type {
  GameSyncClientMessage, GameSyncServerMessage, DisplayRecoveryMessage,
  DisplayCheckpointEnvelope, GameSyncManifestExtension, TerminalDisplayBootstrap,
  GameSyncRejectionCode
} from "./generated/game-sync-types.js";
import {
  validateGameSyncClientMessage, validateGameSyncServerMessage, validateDisplayRecoveryMessage,
  validateDisplayCheckpointEnvelope, validateGameSyncManifestExtension, validateTerminalDisplayBootstrap
} from "./generated/game-sync-validators.js";
import { GAME_SYNC_LIMITS } from "./generated/game-sync-limits.js";

export * from "./generated/game-sync-types.js";
export { GAME_SYNC_LIMITS } from "./generated/game-sync-limits.js";

export interface GameSyncDocuments {
  wire: GameSyncClientMessage;
  "server-wire": GameSyncServerMessage;
  recovery: DisplayRecoveryMessage;
  checkpoint: DisplayCheckpointEnvelope;
  "manifest-extension": GameSyncManifestExtension;
  "terminal-bootstrap": TerminalDisplayBootstrap;
}
export type GameSyncDocumentKind = keyof GameSyncDocuments;
export type GameSyncRole = "controller" | "display";
export type GameSyncValidationCode = GameSyncRejectionCode | "checkpoint_too_large" | "snapshot_invalid" | "roster_invalid" | "result_conflict";
export type GameSyncValidation<T> = { ok: true; value: T } | { ok: false; code: GameSyncValidationCode };
const shapes: Record<GameSyncDocumentKind, (value: unknown) => boolean> = {
  wire: validateGameSyncClientMessage, "server-wire": validateGameSyncServerMessage,
  recovery: validateDisplayRecoveryMessage, checkpoint: validateDisplayCheckpointEnvelope,
  "manifest-extension": validateGameSyncManifestExtension, "terminal-bootstrap": validateTerminalDisplayBootstrap
};

// Check before the recursive schema validators. JSON.stringify would otherwise
// silently omit undefined/functions and turn non-finite numbers into null.
function isFiniteJson(value: unknown, depth: number, ancestors = new Set<object>()): value is JsonValue {
  if (depth < 0) return false;
  if (value === null || typeof value === "string" || typeof value === "boolean") return true;
  if (typeof value === "number") return Number.isFinite(value);
  if (typeof value !== "object" || ancestors.has(value)) return false;
  if (!Array.isArray(value) && Object.getPrototypeOf(value) !== Object.prototype && Object.getPrototypeOf(value) !== null) return false;
  const array = Array.isArray(value);
  for (const key of Reflect.ownKeys(value)) {
    if (array && key === "length") continue;
    const descriptor = Object.getOwnPropertyDescriptor(value, key)!;
    if (typeof key !== "string" || !descriptor.enumerable || !("value" in descriptor)
        || (array && (!/^(0|[1-9][0-9]*)$/.test(key) || Number(key) >= value.length))) return false;
  }
  ancestors.add(value);
  const valid = (Array.isArray(value) ? Array.from(value) : Object.values(value))
    .every(child => isFiniteJson(child, depth - 1, ancestors));
  ancestors.delete(value);
  return valid;
}

function semanticCode<K extends GameSyncDocumentKind>(kind: K, value: GameSyncDocuments[K], role?: GameSyncRole): GameSyncValidationCode | null {
  if (kind === "wire") {
    const message = value as GameSyncClientMessage;
    if (role !== "controller" && role !== "display") return "role_invalid";
    if (role === "controller" && (message.type.startsWith("game.publication.") || "target" in message)) return "role_invalid";
    if (role === "display" && (message.type.startsWith("game.state.") || (message.type === "game.event" && !message.target))) return "role_invalid";
    if (message.scope.kind === "session" && (role === "display" || !message.type.startsWith("game.state."))) return "role_invalid";
  }
  if (kind === "server-wire") {
    const message = value as GameSyncServerMessage;
    if (message.type === "game.delivery.begin") {
      if ((message.mode === "snapshot") !== (message.baseRevision === null)) return "snapshot_invalid";
      if ((message.entryCount === 0) !== (message.partCount === 0) || (message.entryCount === 0) !== (message.totalBytes === 0)) return "transfer_invalid";
    }
    if (message.type === "game.receipt" && (message.publicationId === null) !== (message.publicationRevision === null)) return "invalid_game_message";
    if (message.type === "game.run.changed") {
      if (message.sessionState === "playing" && (message.scope.kind !== "run" || message.startedAt === null)) return "binding_stale";
      if (message.scope.kind === "session" && message.startedAt !== null) return "binding_stale";
    }
  }
  if (kind === "recovery") {
    const message = value as DisplayRecoveryMessage;
    if (message.type === "display.recovery.claimed" && message.recovery.mode === "indexeddb"
        && message.recovery.initialization === "initialized" && message.recovery.disposition === "fresh") return "initialization_invalid";
  }
  if (kind === "checkpoint" || kind === "terminal-bootstrap") {
    const document = value as DisplayCheckpointEnvelope | TerminalDisplayBootstrap;
    if (new Set(document.roster.map(player => player.playerId)).size !== document.roster.length
        || new Set(document.roster.map(player => player.slot)).size !== document.roster.length) return "roster_invalid";
    const rankings = "terminalOutcome" in document
      ? document.terminalOutcome?.kind === "finish" ? document.terminalOutcome.payload.rankings : undefined
      : "rankings" in document.outcome ? document.outcome.rankings : undefined;
    if (rankings && (new Set(rankings.map(ranking => ranking.playerId)).size !== rankings.length
        || rankings.some(ranking => !document.roster.some(player => player.playerId === ranking.playerId)))) return "result_conflict";
  }
  return null;
}

function documentPayloads(document: GameSyncDocuments[GameSyncDocumentKind], kind: GameSyncDocumentKind): { payloads: JsonValue[]; payloadLimit: number } {
  let payloads: JsonValue[] = [];
  let payloadLimit: number = GAME_SYNC_LIMITS.statePayloadBytes;
  if ("payload" in document) payloads = [document.payload];
  if ("entries" in document) payloads = document.entries.flatMap(entry => entry.operation === "put" ? [entry.payload] : []);
  if ("type" in document && (document.type === "game.event" || document.type === "game.event.received")) payloadLimit = GAME_SYNC_LIMITS.eventPayloadBytes;
  if (kind === "checkpoint") payloadLimit = GAME_SYNC_LIMITS.checkpointBytes;
  return { payloads, payloadLimit };
}

/** Shape and cross-field checks. Authentication, epochs, readiness, resource
 * reservations and raw received byte limits are enforced by the transport.
 * Client messages require the authenticated role; omitting it fails closed. */
export function validateGameSyncDocument<K extends GameSyncDocumentKind>(kind: K, value: unknown, role?: GameSyncRole): GameSyncValidation<GameSyncDocuments[K]> {
  const shape = shapes[kind];
  if (!shape || !isFiniteJson(value, 64) || !shape(value)) return { ok: false, code: "invalid_game_message" };
  const document = value as GameSyncDocuments[K];
  if (documentPayloads(document, kind).payloads.some(payload => !isFiniteJson(payload, 31))) return { ok: false, code: "invalid_game_message" };
  const code = semanticCode(kind, document, role);
  return code ? { ok: false, code } : { ok: true, value: document };
}

/** Validate the actual outgoing JSON representation. Incoming Gateway frames
 * use raw JSON spans; reserializing received objects is not byte accounting. */
export function encodeGameSyncDocument<K extends GameSyncDocumentKind>(kind: K, value: unknown, role?: GameSyncRole): GameSyncValidation<string> {
  const checked = validateGameSyncDocument(kind, value, role);
  if (!checked.ok) return checked;
  const document = checked.value;
  const { payloads, payloadLimit } = documentPayloads(document, kind);
  const bytes = (json: string) => new TextEncoder().encode(json).byteLength;
  for (const payload of payloads) {
    if (bytes(JSON.stringify(payload)) > payloadLimit) return { ok: false, code: kind === "checkpoint" ? "checkpoint_too_large" : payloadLimit === GAME_SYNC_LIMITS.eventPayloadBytes ? "event_too_large" : "state_too_large" };
  }
  const json = JSON.stringify(document);
  const frameLimit = kind === "checkpoint" ? GAME_SYNC_LIMITS.checkpointBytes : GAME_SYNC_LIMITS.frameBytes;
  if (bytes(json) > frameLimit) return { ok: false, code: kind === "checkpoint" ? "checkpoint_too_large" : "frame_too_large" };
  return { ok: true, value: json };
}

export * from "./game-sync-runtime.js";

export * from "./game-sync-sender.js";

export * from "./game-sync-clock.js";
export * from "./game-sync-attempt.js";
