import assert from "node:assert/strict";
import { test } from "node:test";
import { GameServerClock } from "./game-sync.js";
test("clock uses the minimum RTT sample and monotonic elapsed time", () => {
  let now = 100;
  const clock = new GameServerClock(() => now);
  assert.equal(clock.getEstimate().stale, true);
  clock.sent("fast");
  now += 20;
  clock.received("fast", 1000);
  assert.deepEqual(clock.getEstimate(), {
    serverTime: 1010,
    uncertaintyMs: 10,
    sampleAgeMs: 0,
    stale: false,
  });
  clock.sent("slow");
  now += 100;
  clock.received("slow", 1100);
  assert.equal(clock.getEstimate().serverTime, 1110);
  assert.equal(clock.getEstimate().uncertaintyMs, 10);
  now += 30001;
  assert.equal(clock.getEstimate().stale, true);
  now += 30000;
  assert.equal(clock.getEstimate().serverTime, null);
});
test("old connection and uncorrelated replies never provide a clock sample", () => {
  let now = 0;
  const clock = new GameServerClock(() => now);
  clock.received("unknown", 1000);
  assert.equal(clock.getEstimate().serverTime, null);
  clock.sent("old");
  clock.reset();
  now = 20;
  clock.received("old", 1000);
  assert.equal(clock.getEstimate().serverTime, null);
  clock.sent("hidden");
  clock.suspend(true);
  now = 40;
  clock.received("hidden", 1000);
  assert.equal(clock.getEstimate().stale, true);
  clock.suspend(false);
  clock.sent("fresh");
  now = 60;
  clock.received("fresh", 2000);
  assert.equal(clock.getEstimate().stale, false);
});

test("a fresh slower heartbeat replaces an expired minimum-RTT sample", () => {
  let now = 0;
  const clock = new GameServerClock(() => now);
  clock.sent("initial"); now = 2; clock.received("initial",1000);
  now = 20000; clock.sent("current"); now = 20020; clock.received("current",21009);
  now = 30002;
  assert.equal(clock.getEstimate().uncertaintyMs,1);
  now = 30003;
  assert.deepEqual(clock.getEstimate(),{serverTime:31002,uncertaintyMs:10,sampleAgeMs:9983,stale:false});
  now = 50021;
  assert.equal(clock.getEstimate().stale,true);
});

test("equal RTT prefers the newest valid heartbeat anchor", () => {
  let now = 0;
  const clock = new GameServerClock(() => now);
  clock.sent("first"); now = 2; clock.received("first",1000);
  now = 20000; clock.sent("latest"); now = 20002; clock.received("latest",21000);
  assert.equal(clock.getEstimate().sampleAgeMs,0);
  now = 30003;
  assert.equal(clock.getEstimate().stale,false);
  assert.equal(clock.getEstimate().sampleAgeMs,10001);
});
