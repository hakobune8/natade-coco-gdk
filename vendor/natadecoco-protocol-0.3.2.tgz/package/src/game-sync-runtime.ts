import type { JsonValue, SessionState } from "./index.js";
import {
  GAME_SYNC_LIMITS, validateGameSyncDocument,
  type GameSyncDeliveryEntry, type GameSyncServerMessage, type GameSyncRunScope,
  type GameSyncRole, type GameSyncValidationCode, type GameSyncSender, type GameSyncSyncReason
} from "./game-sync.js";

export type ReadonlyJsonValue = null | boolean | number | string | readonly ReadonlyJsonValue[] | { readonly [key: string]: ReadonlyJsonValue };
export type DeepReadonly<T> = [JsonValue] extends [T] ? ReadonlyJsonValue : T extends object ? { readonly [K in keyof T]: DeepReadonly<T[K]> } : T;
export type GameScope = GameSyncServerMessage["scope"];
export type ReceivedState = GameSyncDeliveryEntry & {
  scope: GameScope; deliveryRevision: number; checkpointRevision: number | null;
};
export interface ReceivedEvent {
  scope: GameSyncRunScope; sender: GameSyncSender; name: string; payload: JsonValue;
  messageId: string; eventSequence: number; gatewayAcceptedAt: number;
}
export interface GameDeliverySnapshot {
  scope: GameScope | null; revision: number | null; publicationRevision: number | null;
  checkpointRevision: number | null; authorityEpoch: string | null; states: ReceivedState[];
}
export interface GameSyncStatus {
  state: "legacy" | "syncing" | "ready" | "source-unavailable" | "failed";
  sessionId: string; runId?: string; authorityEpoch?: string;
  publicationRevision?: number; checkpointRevision?: number; reason?: GameSyncSyncReason;
}
export interface GameRunMetadata {
  sessionId: string; gameId: string; scope: GameScope;
  startedAt: number | null; sessionState: SessionState;
}
export interface GameDeliveryBinding {
  sessionId: string; gameId: string; connectionId: string; epoch: string;
  scope: GameScope; role: GameSyncRole; playerId?: string;
}
export interface DeliveryReceiverOptions {
  binding: GameDeliveryBinding;
  now(): number;
  setTimeout(callback: () => void, milliseconds: number): ReturnType<typeof setTimeout>;
  clearTimeout(handle: ReturnType<typeof setTimeout>): void;
  onInvalid(reason: GameSyncValidationCode): void;
  onListenerError(error: unknown): void;
  onInputAcknowledgement?(messageIds: readonly string[]): void;
}
type Begin = Extract<GameSyncServerMessage, { type: "game.delivery.begin" }>;
interface Stage {
  begin: Begin; entries: GameSyncDeliveryEntry[]; parts: number; bytes: number;
  deadline: number; keys: Set<string>; inputParts: string[];
}
const bytes = (value: string) => new TextEncoder().encode(value).byteLength;
const sameScope = (a: GameScope, b: GameScope) => a.kind === b.kind && (a.kind === "session" || b.kind === "run" && a.runId === b.runId);
function immutable<T>(value: T): DeepReadonly<T> {
  const owned = structuredClone(value);
  const freeze = (node: unknown): void => {
    if (node && typeof node === "object") { for (const child of Object.values(node)) freeze(child); Object.freeze(node); }
  };
  freeze(owned);
  return owned as DeepReadonly<T>;
}
function stateKey(entry: GameSyncDeliveryEntry): string {
  return JSON.stringify([entry.sender.role, entry.sender.role === "controller" ? entry.sender.playerId : "", entry.target.kind, entry.target.kind === "player" ? entry.target.playerId : "", entry.name]);
}
function senderKey(sender: GameSyncSender): string {
  return JSON.stringify(sender.role === "display" ? [sender.role] : [sender.role, sender.playerId]);
}

/** A pure recipient-side delivery boundary shared by both SDKs. Socket owners
 * supply lifecycle/timers and close/reconnect after onInvalid; games never need
 * to assemble parts, maintain revisions or acknowledge raw input frames. */
export class GameDeliveryReceiver {
  private readonly binding: GameDeliveryBinding;
  private stage: Stage | undefined;
  private timer: ReturnType<typeof setTimeout> | undefined;
  private stopped = false;
  private snapshot: DeepReadonly<GameDeliverySnapshot> = immutable({ scope: null, revision: null, publicationRevision: null, checkpointRevision: null, authorityEpoch: null, states: [] });
  private status: DeepReadonly<GameSyncStatus>;
  private states = new Map<string, ReceivedState>();
  private sequences = new Map<string, number>();
  private eventSequences = new Map<string, { epoch: string; sequence: number }>();
  private readonly snapshotListeners = new Set<(value: DeepReadonly<GameDeliverySnapshot>) => void>();
  private readonly stateListeners = new Set<(value: DeepReadonly<ReceivedState>) => void>();
  private readonly eventListeners = new Set<(value: DeepReadonly<ReceivedEvent>) => void>();
  private readonly syncListeners = new Set<(value: DeepReadonly<GameSyncStatus>) => void>();
  private readonly runListeners = new Set<(value: DeepReadonly<GameRunMetadata>) => void>();

  constructor(private readonly options: DeliveryReceiverOptions) {
    this.binding = structuredClone(options.binding);
    this.status = immutable({ state: "syncing", sessionId: this.binding.sessionId, ...(this.binding.scope.kind === "run" ? { runId: this.binding.scope.runId } : {}) });
  }
  getGameSnapshot(): DeepReadonly<GameDeliverySnapshot> { return this.snapshot; }
  getSyncStatus(): DeepReadonly<GameSyncStatus> { return this.status; }
  onGameSnapshot(listener: (value: DeepReadonly<GameDeliverySnapshot>) => void): () => void { this.snapshotListeners.add(listener); return () => this.snapshotListeners.delete(listener); }
  onState(listener: (value: DeepReadonly<ReceivedState>) => void): () => void { this.stateListeners.add(listener); return () => this.stateListeners.delete(listener); }
  onEvent(listener: (value: DeepReadonly<ReceivedEvent>) => void): () => void { this.eventListeners.add(listener); return () => this.eventListeners.delete(listener); }
  onSyncChanged(listener: (value: DeepReadonly<GameSyncStatus>) => void): () => void { this.syncListeners.add(listener); return () => this.syncListeners.delete(listener); }
  onRunChanged(listener: (value: DeepReadonly<GameRunMetadata>) => void): () => void { this.runListeners.add(listener); return () => this.runListeners.delete(listener); }

  /** Only delivery/event/status/run messages are consumed. Receipts and recovery
   * acknowledgements are correlated separately by the sending client. */
  receive(raw: string): boolean {
    let value: unknown;
    try { value = JSON.parse(raw); } catch { this.fail("invalid_game_message"); return true; }
    if (!value || typeof value !== "object" || !("type" in value) || typeof value.type !== "string") return false;
    const type = value.type;
    if (!type.startsWith("game.delivery.") && type !== "game.event.received" && type !== "game.sync.changed" && type !== "game.run.changed") return false;
    if (this.stopped) return true;
    const size = bytes(raw);
    if (size > GAME_SYNC_LIMITS.frameBytes) { this.fail("frame_too_large"); return true; }
    const checked = validateGameSyncDocument("server-wire", value);
    if (!checked.ok) { this.fail(checked.code); return true; }
    const message = checked.value;
    if (message.sessionId !== this.binding.sessionId || message.gameId !== this.binding.gameId || message.connectionId !== this.binding.connectionId || message.epoch !== this.binding.epoch || !sameScope(message.scope, this.binding.scope)) { this.fail("binding_stale"); return true; }
    const stream = type.startsWith("game.delivery.") ? "delivery" : type;
    const prior = this.sequences.get(stream);
    if (prior !== undefined && message.sequence <= prior) { this.fail("snapshot_invalid"); return true; }
    this.sequences.set(stream, message.sequence);
    if (this.stage && this.options.now() >= this.stage.deadline) { this.fail("transfer_timeout"); return true; }
    switch (message.type) {
      case "game.delivery.begin": this.begin(message); break;
      case "game.delivery.part": this.part(message, size); break;
      case "game.delivery.end": this.end(message); break;
      case "game.sync.changed":
        if (message.sourceState === "ready" && (this.snapshot.revision === null || this.snapshot.authorityEpoch !== message.authorityEpoch)) { this.fail("snapshot_invalid"); break; }
        this.updateStatus(message.sourceState, message.authorityEpoch, message.reason); break;
      case "game.event.received": this.event(message); break;
      case "game.run.changed":
        this.notify(this.runListeners, immutable({ sessionId: message.sessionId, gameId: message.gameId, scope: message.scope, startedAt: message.startedAt, sessionState: message.sessionState }));
        break;
    }
    return true;
  }
  private begin(message: Begin): void {
    if (this.stage || message.entryCount > GAME_SYNC_LIMITS.totalKeysPerRun || message.partCount > GAME_SYNC_LIMITS.transferParts || message.totalBytes > GAME_SYNC_LIMITS.transferBytes || message.mode === "publication" && (this.snapshot.revision === null || message.baseRevision !== this.snapshot.revision || message.revision !== this.snapshot.revision + 1)) { this.fail("snapshot_invalid"); return; }
    this.stage = { begin: structuredClone(message), entries: [], parts: 0, bytes: 0, deadline: this.options.now() + 5000, keys: new Set(), inputParts: [] };
    this.timer = this.options.setTimeout(() => this.fail("transfer_timeout"), 5000);
  }
  private part(message: Extract<GameSyncServerMessage, { type: "game.delivery.part" }>, size: number): void {
    const stage = this.stage;
    if (!stage || message.deliveryId !== stage.begin.deliveryId || message.partIndex !== stage.parts || stage.parts >= stage.begin.partCount || stage.bytes + size > stage.begin.totalBytes || stage.entries.length + message.entries.length > stage.begin.entryCount) { this.fail("transfer_invalid"); return; }
    for (const entry of message.entries) {
      const key = stateKey(entry);
      if (stage.keys.has(key) || !this.authorized(entry, stage.begin.authorityEpoch)) { this.fail("snapshot_invalid"); return; }
      // Raw frame bytes bound staging. Parsed payload accounting remains
      // conservative about escaping rather than silently removing validation.
      if (entry.operation === "put" && bytes(JSON.stringify(entry.payload)) > GAME_SYNC_LIMITS.statePayloadBytes) { this.fail("state_too_large"); return; }
      stage.keys.add(key);
      stage.entries.push(structuredClone(entry));
    }
    if (message.entries.some(entry => entry.operation === "put" && entry.name === "platform.input")) stage.inputParts.push(message.messageId);
    stage.parts++; stage.bytes += size;
  }
  private end(message: Extract<GameSyncServerMessage, { type: "game.delivery.end" }>): void {
    const stage = this.stage;
    if (!stage || message.deliveryId !== stage.begin.deliveryId || stage.parts !== stage.begin.partCount || stage.bytes !== stage.begin.totalBytes || stage.entries.length !== stage.begin.entryCount) { this.fail("transfer_invalid"); return; }
    const begin = stage.begin;
    const next = begin.mode === "snapshot" ? new Map<string, ReceivedState>() : new Map(this.states);
    const changed = stage.entries.map(entry => ({ ...entry, scope: begin.scope, deliveryRevision: begin.revision, checkpointRevision: begin.checkpointRevision }));
    for (const entry of changed) {
      const key = stateKey(entry);
      if (entry.operation === "clear") next.delete(key); else next.set(key, entry);
    }
    if (!this.withinCacheBudget(next, begin)) { this.fail("cache_limit"); return; }
    this.clearStage();
    this.states = next;
    this.snapshot = immutable({ scope: begin.scope, revision: begin.revision, publicationRevision: begin.publicationRevision, checkpointRevision: begin.checkpointRevision, authorityEpoch: begin.authorityEpoch, states: [...next.values()] });
    this.updateStatus(begin.sourceState, begin.authorityEpoch, null, false);
    // All state is committed before any subscriber can read it.
    this.notify(this.snapshotListeners, this.snapshot);
    for (const entry of changed) this.notify(this.stateListeners, immutable(entry));
    this.notify(this.syncListeners, this.status);
    if (stage.inputParts.length) this.options.onInputAcknowledgement?.(stage.inputParts);
  }
  private authorized(entry: GameSyncDeliveryEntry, authorityEpoch: string | null): boolean {
    if (this.binding.role === "display") return entry.sender.role === "controller" && entry.target.kind === "display";
    return entry.sender.role === "display" && entry.sender.authorityEpoch === authorityEpoch && (entry.target.kind === "all-controllers" || entry.target.kind === "player" && entry.target.playerId === this.binding.playerId);
  }
  private withinCacheBudget(states: Map<string, ReceivedState>, begin: Begin): boolean {
    if (states.size > GAME_SYNC_LIMITS.totalKeysPerRun) return false;
    let display = 0;
    const players = new Map<string, number>();
    const entries: GameSyncDeliveryEntry[] = [];
    for (const state of states.values()) {
      if (state.sender.role === "display") display++;
      else players.set(state.sender.playerId, (players.get(state.sender.playerId) ?? 0) + 1);
      const entry = { operation: state.operation, name: state.name, sender: state.sender, target: state.target, stateSequence: state.stateSequence, gatewayAcceptedAt: state.gatewayAcceptedAt, publicationRevision: state.publicationRevision };
      entries.push(state.operation === "put" ? { ...entry, operation: "put", payload: state.payload } : { ...entry, operation: "clear" });
    }
    return display <= GAME_SYNC_LIMITS.displayKeysPerRun && [...players.values()].every(count => count <= 16)
      && bytes(JSON.stringify({ sessionId: this.binding.sessionId, gameId: this.binding.gameId, scope: begin.scope, authorityEpoch: begin.authorityEpoch, entries })) <= GAME_SYNC_LIMITS.cacheBytesPerRun;
  }
  private event(message: Extract<GameSyncServerMessage, { type: "game.event.received" }>): void {
    if (this.status.state !== "ready" || this.snapshot.revision === null || this.stage?.begin.mode === "snapshot") return;
    const sender = message.sender;
    if (this.binding.role === "controller" && (sender.role !== "display" || sender.authorityEpoch !== this.snapshot.authorityEpoch) || this.binding.role === "display" && sender.role !== "controller") { this.fail("snapshot_invalid"); return; }
    const key = senderKey(sender), prior = this.eventSequences.get(key);
    const epoch = sender.role === "display" ? sender.authorityEpoch : sender.inputEpoch;
    if (prior?.epoch === epoch && message.eventSequence <= prior.sequence) return;
    if (!this.eventSequences.has(key) && this.eventSequences.size >= 256) this.eventSequences.delete(this.eventSequences.keys().next().value!);
    if (bytes(JSON.stringify(message.payload)) > GAME_SYNC_LIMITS.eventPayloadBytes) { this.fail("event_too_large"); return; }
    this.eventSequences.set(key, { epoch, sequence: message.eventSequence });
    const event: ReceivedEvent = { scope: message.scope, sender: message.sender, name: message.name, payload: message.payload, messageId: message.messageId, eventSequence: message.eventSequence, gatewayAcceptedAt: message.gatewayAcceptedAt };
    this.notify(this.eventListeners, immutable(event));
  }
  private updateStatus(state: GameSyncStatus["state"], epoch: string | null, reason: GameSyncSyncReason | null, notify = true): void {
    this.status = immutable({ state, sessionId: this.binding.sessionId,
      ...(this.binding.scope.kind === "run" ? { runId: this.binding.scope.runId } : {}),
      ...(epoch !== null ? { authorityEpoch: epoch } : {}),
      ...(this.snapshot.publicationRevision !== null ? { publicationRevision: this.snapshot.publicationRevision } : {}),
      ...(this.snapshot.checkpointRevision !== null ? { checkpointRevision: this.snapshot.checkpointRevision } : {}), ...(reason !== null ? { reason } : {}) });
    if (notify) this.notify(this.syncListeners, this.status);
  }
  private notify<T>(listeners: Set<(value: T) => void>, value: T): void {
    for (const listener of listeners) {
      try { listener(value); } catch (error) { this.options.onListenerError(error); }
    }
  }
  private clearStage(): void {
    if (this.timer !== undefined) this.options.clearTimeout(this.timer);
    this.timer = undefined; this.stage = undefined;
  }
  private fail(reason: GameSyncValidationCode): void {
    if (this.stopped) return;
    this.stopped = true; this.clearStage();
    this.updateStatus("syncing", this.snapshot.authorityEpoch, reason === "binding_stale" ? "binding_changed" : "snapshot_invalid");
    this.options.onInvalid(reason);
  }
  disconnect(): void { if (!this.stopped) { this.stopped = true; this.clearStage(); this.updateStatus("syncing", this.snapshot.authorityEpoch, "binding_changed"); } }
  destroy(): void {
    this.disconnect(); this.snapshotListeners.clear(); this.stateListeners.clear(); this.eventListeners.clear(); this.syncListeners.clear(); this.runListeners.clear();
  }
}
