import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { test } from "node:test";
import { encodeGameSyncDocument, validateGameSyncDocument, GAME_SYNC_LIMITS } from "./game-sync.js";
import type { GameSyncDocumentKind, GameSyncRole } from "./game-sync.js";
import type { JsonValue } from "./index.js";

interface Fixture {
  schema: GameSyncDocumentKind; value: unknown; role?: GameSyncRole; label?: string; expectedCode?: string;
}
const fixtures: { valid: Fixture[]; invalid: Fixture[]; semanticInvalid: Fixture[]; encodedPayloads: { payload: string; utf8Bytes: number }[] } = JSON.parse(readFileSync(new URL("../../../../docs/rfc/contracts/game-sync-v1/fixtures.json", import.meta.url), "utf8"));
for (const [index, fixture] of fixtures.valid.entries()) {
  test(`accepted contract fixture ${index}: ${fixture.schema}`, () => {
    assert.equal(validateGameSyncDocument(fixture.schema, fixture.value, fixture.role).ok, true);
    assert.equal(encodeGameSyncDocument(fixture.schema, fixture.value, fixture.role).ok, true);
  });
}
for (const [index, fixture] of fixtures.invalid.entries()) {
  test(`rejected shape ${index}: ${fixture.label}`, () => {
    assert.deepEqual(validateGameSyncDocument(fixture.schema, fixture.value, fixture.role), { ok: false, code: "invalid_game_message" });
  });
}
for (const fixture of fixtures.semanticInvalid) {
  test(`rejected semantics: ${fixture.label}`, () => {
    assert.deepEqual(validateGameSyncDocument(fixture.schema, fixture.value, fixture.role), { ok: false, code: fixture.expectedCode });
  });
}
const state = fixtures.valid.find(fixture => (fixture.value as { type?: string }).type === "game.state.put")!.value as Record<string, unknown>;
const event: Record<string, unknown> = { ...state, type: "game.event", eventSequence: 0 };
delete event.stateSequence;
test("UTF-8 budgets accept the boundary and reject one additional character", () => {
  for (const [character, width] of [["x", 1], ["あ", 3], ["😀", 4]] as const) {
    const count = Math.floor((GAME_SYNC_LIMITS.statePayloadBytes - 2) / width);
    assert.equal(encodeGameSyncDocument("wire", { ...state, payload: character.repeat(count) }, "controller").ok, true);
    assert.deepEqual(encodeGameSyncDocument("wire", { ...state, payload: character.repeat(count + 1) }, "controller"), { ok: false, code: "state_too_large" });
    const events = Math.floor((GAME_SYNC_LIMITS.eventPayloadBytes - 2) / width);
    assert.equal(encodeGameSyncDocument("wire", { ...event, payload: character.repeat(events) }, "controller").ok, true);
    assert.deepEqual(encodeGameSyncDocument("wire", { ...event, payload: character.repeat(events + 1) }, "controller"), { ok: false, code: "event_too_large" });
  }
});
test("HTML, Unicode separators and surrogate pairs retain their JSON encoding", () => {
  for (const fixture of fixtures.encodedPayloads) {
    assert.equal(Buffer.byteLength(JSON.stringify(fixture.payload)), fixture.utf8Bytes);
    const result = encodeGameSyncDocument("wire", { ...state, payload: fixture.payload.repeat(7281) }, "controller");
    assert.equal(result.ok, true);
    if (result.ok) assert.equal(JSON.parse(result.value).payload, fixture.payload.repeat(7281));
  }
});
test("plain finite JSON only, including cyclic, sparse and omitted values", () => {
  const cyclic: Record<string, unknown> = {}; cyclic.self = cyclic;
  const hidden = Object.defineProperty({}, "secret", { value: 1 });
  const getter = Object.defineProperty({}, "value", { enumerable: true, get: () => 1 });
  const symbol = { [Symbol("value")]: 1 };
  const extraArrayProperty = Object.assign([], { 4294967295: 1 });
  for (const payload of [undefined, NaN, Infinity, () => 1, new Date(), cyclic, [undefined], Array(1), hidden, getter, symbol, extraArrayProperty]) {
    assert.deepEqual(validateGameSyncDocument("wire", { ...state, payload }, "controller"), { ok: false, code: "invalid_game_message" });
  }
  assert.equal(validateGameSyncDocument("wire", { ...state, payload: Object.assign(Object.create(null), { value: null }) }, "controller").ok, true);
});
test("payload depth 31 passes; depth 32 fails before recursive schema validation", () => {
  let payload: JsonValue = null;
  for (let i = 0; i < 31; i++) payload = [payload];
  assert.equal(validateGameSyncDocument("wire", { ...state, payload }, "controller").ok, true);
  assert.deepEqual(validateGameSyncDocument("wire", { ...state, payload: [payload] }, "controller"), { ok: false, code: "invalid_game_message" });
});
test("legacy envelope dispatcher does not accept new messages implicitly", async () => {
  const { isProtocolEnvelope } = await import("./index.js");
  assert.equal(isProtocolEnvelope(state), false);
});

test("a valid client message requires an authenticated role", () => {
  assert.deepEqual(validateGameSyncDocument("wire", state), { ok: false, code: "role_invalid" });
});
