import assert from "node:assert/strict";
import { test } from "node:test";
import { GameDeliveryReceiver, type GameSyncDeliveryEntry, type GameDeliveryBinding } from "./game-sync.js";
const binding: GameDeliveryBinding = { sessionId: "session", gameId: "game", connectionId: "connection", epoch: "input", scope: { kind: "run", runId: "run" }, role: "controller", playerId: "p1" };
function harness(override: Partial<GameDeliveryBinding> = {}) {
  let now = 0, sequence = 0;
  const timers = new Map<number, () => void>(); let timerId = 0;
  const invalid: string[] = [], acks: string[][] = [], listenerErrors: unknown[] = [];
  const receiver = new GameDeliveryReceiver({ binding: { ...binding, ...override }, now: () => now,
    setTimeout: (callback) => { timers.set(++timerId, callback); return timerId as unknown as ReturnType<typeof setTimeout>; },
    clearTimeout: id => { timers.delete(id as unknown as number); }, onInvalid: code => invalid.push(code), onListenerError: error => listenerErrors.push(error), onInputAcknowledgement: ids => acks.push([...ids]) });
  const envelope = (type: string) => ({ protocolVersion: "1.0", gameSyncVersion: 1, type, messageId: `mid-${sequence}`, sessionId: "session", gameId: "game", connectionId: "connection", epoch: "input", sequence: sequence++, scope: { kind: "run", runId: "run" } });
  const delivery = (entries: GameSyncDeliveryEntry[], revision = 0, snapshot = true, sourceState = "ready") => {
    const id = `delivery-${sequence}`;
    // Create all frames in actual wire order, then account the complete part.
    const begin = { ...envelope("game.delivery.begin"), deliveryId: id, mode: snapshot ? "snapshot" : "publication", revision, baseRevision: snapshot ? null : revision - 1,
      publicationRevision: 1, checkpointRevision: 0, authorityEpoch: "authority", sourceState, entryCount: entries.length, partCount: entries.length ? 1 : 0, totalBytes: 0 };
    const part = entries.length ? { ...envelope("game.delivery.part"), deliveryId: id, partIndex: 0, entries } : null;
    if (part) begin.totalBytes = new TextEncoder().encode(JSON.stringify(part)).byteLength;
    const end = { ...envelope("game.delivery.end"), deliveryId: id };
    return { begin, part, end };
  };
  const send = (value: unknown) => receiver.receive(JSON.stringify(value));
  return { receiver, invalid, acks, listenerErrors, envelope, delivery, send, timers, advance: () => { now = 5000; for (const callback of timers.values()) callback(); } };
}
const view = (name = "view", payload = "value"): GameSyncDeliveryEntry => ({ name, sender: { role: "display", authorityEpoch: "authority" }, target: { kind: "player", playerId: "p1" }, stateSequence: 1, gatewayAcceptedAt: 100, publicationRevision: 1, operation: "put", payload: { value: payload } });
function complete(h: ReturnType<typeof harness>, frames: ReturnType<ReturnType<typeof harness>["delivery"]>) { h.send(frames.begin); if (frames.part) h.send(frames.part); h.send(frames.end); }

test("delivery applies atomically before callbacks, freezes values and clears explicit tombstones", () => {
  const h = harness(); let snapshots = 0, states = 0;
  h.receiver.onGameSnapshot(value => { snapshots++; assert.equal(value.states.length, 2); });
  const unsubscribe = h.receiver.onState(() => { states++; assert.equal(h.receiver.getGameSnapshot().states.length, 2); });
  const frames = h.delivery([view("hand"), view("score")]);
  h.send(frames.begin); h.send(frames.part);
  assert.equal(h.receiver.getGameSnapshot().revision, null); assert.equal(snapshots, 0);
  h.send(frames.end); assert.equal(snapshots, 1); assert.equal(states, 2);
  assert.equal(h.receiver.getSyncStatus().state, "ready"); assert.equal(h.timers.size, 0);
  const entry = h.receiver.getGameSnapshot().states[0]!;
  assert.ok(Object.isFrozen(entry)); if (entry.operation === "put") assert.ok(Object.isFrozen(entry.payload));
  unsubscribe();
  const clear: GameSyncDeliveryEntry = { ...view("hand"), operation: "clear" };
  delete (clear as { payload?: unknown }).payload;
  // A separate receiver verifies clear/null without snapshot callback assumptions.
  const c = harness(); complete(c, c.delivery([view("hand")])); complete(c, c.delivery([clear], 1, false));
  assert.equal(c.receiver.getGameSnapshot().states.length, 0);
  const nil = { ...view("hand"), operation: "put" as const, payload: null };
  complete(c, c.delivery([nil], 2, false)); assert.equal(c.receiver.getGameSnapshot().states.length, 1);
  assert.deepEqual(c.invalid, []);
});

test("normal publication preserves ready and old snapshot until end; events are live only", () => {
  const h = harness(); let events = 0; h.receiver.onEvent(() => { events++; });
  const event = () => ({ ...h.envelope("game.event.received"), sender: { role: "display", authorityEpoch: "authority" }, gatewayAcceptedAt: 100, eventSequence: events, name: "hit", payload: {} });
  h.send(event()); assert.equal(events, 0);
  complete(h, h.delivery([view("view", "old")]));
  const frames = h.delivery([view("view", "new")], 1, false); h.send(frames.begin); h.send(frames.part);
  assert.equal(h.receiver.getSyncStatus().state, "ready"); assert.equal(h.receiver.getGameSnapshot().revision, 0);
  h.send(event()); assert.equal(events, 1); h.send(frames.end);
  assert.equal(h.receiver.getGameSnapshot().revision, 1); assert.deepEqual(h.invalid, []);
  h.send({ ...h.envelope("game.sync.changed"), sourceState: "source-unavailable", authorityEpoch: "authority", reason: "source_unavailable" });
  h.send(event()); assert.equal(events, 1); assert.deepEqual(h.invalid, []);
});

test("wrong binding, recipient, authority, repeated parts and revision gaps fail closed", () => {
  for (const mutate of [
    (f: ReturnType<ReturnType<typeof harness>["delivery"]>) => { f.begin.connectionId = "other"; },
    (f: ReturnType<ReturnType<typeof harness>["delivery"]>) => { f.begin.baseRevision = 3; },
    (f: ReturnType<ReturnType<typeof harness>["delivery"]>) => { f.begin.totalBytes++; },
    (f: ReturnType<ReturnType<typeof harness>["delivery"]>) => { if (f.part) (f.part.entries[0]!.target as { playerId: string }).playerId = "p2"; },
    (f: ReturnType<ReturnType<typeof harness>["delivery"]>) => { if (f.part) (f.part.entries[0]!.sender as { authorityEpoch: string }).authorityEpoch = "old"; }
  ]) {
    const h = harness(); complete(h, h.delivery([view()])); const frames = h.delivery([view()], 1, false); mutate(frames); complete(h, frames);
    assert.equal(h.invalid.length, 1); assert.equal(h.receiver.getSyncStatus().state, "syncing"); assert.equal(h.receiver.getGameSnapshot().revision, 0);
  }
  const h = harness(), frames = h.delivery([view()]); h.send(frames.begin); h.send(frames.part); h.send(frames.part); assert.equal(h.invalid.length, 1);
});

test("quiet transfer timeout and destroy release timers; no partial state or input ACK", () => {
  const h = harness(); h.send(h.delivery([view()]).begin); h.advance(); assert.deepEqual(h.invalid, ["transfer_timeout"]); assert.equal(h.timers.size, 0);
  assert.equal(h.receiver.getGameSnapshot().revision, null); assert.deepEqual(h.acks, []);
  const d = harness(); d.send(d.delivery([view()]).begin); d.receiver.destroy(); assert.equal(d.timers.size, 0);
});

test("Display standard input is acknowledged only after the whole delivery is applied", () => {
  const h = harness({ role: "display" });
  const entry: GameSyncDeliveryEntry = { name: "platform.input", sender: { role: "controller", playerId: "p1", inputEpoch: "sender" }, target: { kind: "display" }, stateSequence: 0, gatewayAcceptedAt: 100, publicationRevision: null, operation: "put", payload: { buttons: { a: true } } };
  const frames = h.delivery([entry]); h.send(frames.begin); h.send(frames.part); assert.deepEqual(h.acks, []); h.send(frames.end);
  assert.deepEqual(h.acks, [[frames.part!.messageId]]); assert.deepEqual(h.invalid, []);
});

test("near-limit 128-state snapshot applies completely; excess cache is rejected atomically", () => {
  const h = harness(), entries = Array.from({ length: 128 }, (_, index) => view(`view-${index}`, "x".repeat(15000)));
  const begin = { ...h.envelope("game.delivery.begin"), deliveryId: "large", mode: "snapshot", revision: 0, baseRevision: null, publicationRevision: 1, checkpointRevision: 0, authorityEpoch: "authority", sourceState: "ready", entryCount: 128, partCount: 16, totalBytes: 0 };
  const parts = Array.from({ length: 16 }, (_, index) => ({ ...h.envelope("game.delivery.part"), deliveryId: "large", partIndex: index, entries: entries.slice(index * 8, index * 8 + 8) }));
  begin.totalBytes = parts.reduce((total, part) => total + new TextEncoder().encode(JSON.stringify(part)).byteLength, 0);
  h.send(begin); for (const part of parts) h.send(part); h.send({ ...h.envelope("game.delivery.end"), deliveryId: "large" });
  assert.equal(h.receiver.getGameSnapshot().states.length, 128); assert.deepEqual(h.invalid, []);
  complete(h, h.delivery([view("extra")], 1, false)); assert.deepEqual(h.invalid, ["cache_limit"]);
  assert.equal(h.receiver.getGameSnapshot().states.length, 128); assert.equal(h.receiver.getGameSnapshot().revision, 0);
});

test("a throwing game listener cannot prevent later notifications or corrupt the delivery boundary", () => {
 const h = harness(); let notified = 0;
 h.receiver.onState(() => { throw new Error("game callback"); });
 h.receiver.onState(() => { notified++; assert.equal(h.receiver.getGameSnapshot().states.length, 1); });
 complete(h,h.delivery([view()]));
 assert.equal(notified,1); assert.equal(h.listenerErrors.length,1); assert.deepEqual(h.invalid,[]);
});
