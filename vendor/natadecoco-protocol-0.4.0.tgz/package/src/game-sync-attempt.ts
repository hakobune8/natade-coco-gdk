import { GameSyncError } from "./game-sync-sender.js";

declare const syncAttemptBrand: unique symbol;
/** Opaque instance identity. Serialization cannot transfer an active attempt. */
export interface SyncAttempt { readonly [syncAttemptBrand]: true }
export interface GameSyncReport {
  state: "ready" | "syncing" | "failed";
  /** Game-server revision, separate from checkpoint/publication revisions. */
  revision?: string | number;
  reason?: "game_api_failed";
}
export interface SyncAttemptBinding {
  sessionId: string;
  runId: string;
  connectionId: string;
  epoch: string;
}
const sameBinding = (a: SyncAttemptBinding, b: SyncAttemptBinding) =>
  a.sessionId === b.sessionId && a.runId === b.runId &&
  a.connectionId === b.connectionId && a.epoch === b.epoch;

/** Internal bounded gate shared by Platform and Display. Each module owns a
 * gate; its host invalidates it on disposal and supplies the live binding. */
export class GameSyncAttemptGate {
  private attempt: SyncAttempt | undefined;
  private binding: SyncAttemptBinding | undefined;
  private report: Readonly<GameSyncReport> | undefined;
  private acceptedAttempt: SyncAttempt | undefined;
  constructor(private readonly currentBinding: () => SyncAttemptBinding | undefined) {}
  begin(options: { retainReadyDuringRefresh?: boolean } = {}): SyncAttempt {
    const binding = this.currentBinding();
    if (!binding) throw new GameSyncError("game_sync_not_ready", true);
    // A same-binding background read must not revoke an already accepted
    // ready state just because HTTP is in flight. A changed binding, first
    // read, or failed report still starts in syncing; a failed refresh replaces
    // the retained report when its result arrives.
    const retainReady = options.retainReadyDuringRefresh === true &&
      this.report?.state === "ready" && this.binding !== undefined &&
      sameBinding(binding, this.binding);
    this.binding = { ...binding };
    if (!retainReady) this.report = undefined;
    this.acceptedAttempt = undefined;
    this.attempt = Object.freeze({}) as SyncAttempt;
    return this.attempt;
  }
  accept(attempt: SyncAttempt, report: GameSyncReport): { accepted: boolean } {
    const binding = this.currentBinding();
    if (!this.attempt || attempt !== this.attempt || !binding || !this.binding || !sameBinding(binding, this.binding)) return { accepted: false };
    if (!report || !["ready", "syncing", "failed"].includes(report.state) ||
        (report.reason !== undefined && report.reason !== "game_api_failed") ||
        (report.revision !== undefined && !(typeof report.revision === "number"
          ? Number.isSafeInteger(report.revision) && report.revision >= 0
          : typeof report.revision === "string" && report.revision.length > 0 && report.revision.length <= 128 && [...report.revision].every((character) => character.charCodeAt(0) >= 32 && character.charCodeAt(0) !== 127))))
      throw new GameSyncError("payload_invalid", false);
    this.attempt = undefined;
    this.acceptedAttempt = attempt;
    this.report = Object.freeze({ state: report.state, ...(report.revision === undefined ? {} : { revision: report.revision }), ...(report.reason === undefined ? {} : { reason: report.reason }) });
    return { accepted: true };
  }
  getReport(): Readonly<GameSyncReport> | undefined {
    const binding = this.currentBinding();
    return binding && this.binding && sameBinding(binding, this.binding) ? this.report : undefined;
  }
  isAccepted(attempt: SyncAttempt): boolean {
    return this.acceptedAttempt === attempt && this.getReport() !== undefined;
  }
  invalidate(): void {
    this.attempt = undefined;
    this.binding = undefined;
    this.report = undefined;
    this.acceptedAttempt = undefined;
  }
}
